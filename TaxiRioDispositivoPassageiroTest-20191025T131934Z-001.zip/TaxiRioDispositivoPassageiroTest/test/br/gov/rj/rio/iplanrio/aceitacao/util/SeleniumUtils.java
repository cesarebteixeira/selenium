package br.gov.rj.rio.iplanrio.aceitacao.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;

/**
 * Classe Utils para o Seleium Ela esta implementando a classe
 * 'SeleniumInterface' para utilizar o nome dos browsers
 * 
 * @author Elias Nogueira <elias.nogueira@gmail.com>
 *
 */
public class SeleniumUtils {

	private static AndroidDriver<MobileElement> driver = null;

	public static WebDriver getDriver(String browser) {

		// if (driver == null) {

		String proxyAddr = Utils.getProperties("proxy");

		org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();

		if (!"".equalsIgnoreCase(proxyAddr)) {
			proxy.setHttpProxy(proxyAddr).setFtpProxy(proxyAddr).setSslProxy(proxyAddr)
					.setNoProxy("jdev.rio.rj.gov.br jdev jeap.rio.rj.gov.br jeap jhom.rio.rj.gov.br jhom localhost");
		}

		// se o browser for firefox instancia o driver do Firefox

		// }

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		return (AndroidDriver<MobileElement>) driver;
	}

	/**
	 * Metodo para pegar o valor de alguma propriedade no arquivo de configuracao do
	 * Selenium O caminho e o nome do arquivo pode ser trocados
	 */
	public static String getSeleniumProperties(String name) {
		Properties properties = new Properties();
		String value = null;

		try {
			properties.load(new FileInputStream("selenium.properties")); // se necessitar altere o caminho e/ou o nome
																			// do arquivo
			value = properties.getProperty(name);

		} catch (IOException e) {
			e.printStackTrace();
		}

		return value;
	}

	/**
	 * Alteração para retornar drivers de dispositivos móveis
	 * 
	 * @author Carlos Alberto Valete
	 * 
	 */

	// taxirio private static AndroidDriver<?> androidDriver = null;

	public static AndroidDriver<MobileElement> getAndroidDriver() {
		Properties properties = new Properties();
		File diretorioAplicacao;
		File arquivoAplicacao;
		URL url;

		try {
			properties.load(new FileInputStream("android.properties"));

	////		diretorioAplicacao = new File(properties.getProperty("android.diretorio.aplicacao"));
	//		arquivoAplicacao = new File(diretorioAplicacao, properties.getProperty("android.arquivo.aplicacao"));
	//		url = new URL(properties.getProperty("android.url"));
			DesiredCapabilities capability = new DesiredCapabilities();
			capability.setCapability(MobileCapabilityType.CLEAR_SYSTEM_FILES, "true");
			capability.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
			capability.setCapability("privateDevicesOnly", "true");
			capability.setCapability(MobileCapabilityType.DEVICE_NAME, "0027485642"); // 0027485642(motorola)
																						// 8431513348595a57 (sumsug)
			// capability.setCapability(MobileCapabilityType.APP,
			// arquivoAplicacao.getAbsolutePath());
			// capability.setCapability("appPackage", "br.gov.rj.taxi.rio.driver");
			// Set android appActivity desired capability.
			// capability.setCapability("appPackage", "com.iplanrio.sauderio");
			// capability.setCapability("appActivity", "host.exp.exponent.MainActivity");

			capability.setCapability("appPackage", "br.gov.rj.taxi.rio.passenger");
			capability.setCapability("appActivity", "br.gov.rj.taxi.rio.passenger.activity.MainActivity"); //

			// capability.setCapability("platformVersion", "7.1.1");

			driver = new AndroidDriver<MobileElement>(new URL("http://127.0.0.1:4723/wd/hub"), capability);

			System.out.println(" *** Executando a versão " + properties.getProperty("android.arquivo.aplicacao")
					+ " do passageiro ***");

			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		} catch (IOException e) {
			e.printStackTrace();
		}

		// taxirio return (AndroidDriver<?>) driver;
		return (AndroidDriver<MobileElement>) driver;
	}

	public static AndroidDriver<MobileElement> getAndroidDriverNuvem() {
		Properties properties = new Properties();
		File diretorioAplicacao;
		File arquivoAplicacao;
		URL url;

		try {
			// properties.load(new FileInputStream("android.properties"));

			// diretorioAplicacao = new
			// File(properties.getProperty("android.diretorio.aplicacao"));
			// arquivoAplicacao = new File(diretorioAplicacao,
			// properties.getProperty("android.arquivo.aplicacao"));
			url = new URL(properties.getProperty("android.url"));
			DesiredCapabilities capability = new DesiredCapabilities();
			capability.setCapability(MobileCapabilityType.CLEAR_SYSTEM_FILES, "true");
			capability.setCapability(MobileCapabilityType.PLATFORM_NAME, MobilePlatform.ANDROID);
			capability.setCapability("privateDevicesOnly", "true");
			capability.setCapability(MobileCapabilityType.DEVICE_NAME, "0027485642"); // 0027485642(motorola)
																						// 8431513348595a57 (sumsug)
			// capability.setCapability(MobileCapabilityType.APP,
			// arquivoAplicacao.getAbsolutePath());
			// capability.setCapability("appPackage", "br.gov.rj.taxi.rio.driver");
			// Set android appActivity desired capability.
			capability.setCapability("appPackage", "com.iplanrio.sauderio");
			capability.setCapability("appActivity", "host.exp.exponent.LauncherActivity");

			// capability.setCapability("appPackage", "br.gov.rj.taxi.rio.passenger");
			// capability.setCapability("appActivity",
			// "br.gov.rj.taxi.rio.passenger.activity.MainActivity"); //

			// capability.setCapability("platformVersion", "7.1.1");

			driver = new AndroidDriver<MobileElement>(url, capability);

			// System.out.println(" *** Executando a versão " +
			// properties.getProperty("android.arquivo.aplicacao") + " do passageiro ***");

			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		} catch (IOException e) {
			e.printStackTrace();
		}

		// taxirio return (AndroidDriver<?>) driver;
		return (AndroidDriver<MobileElement>) driver;
	}

}

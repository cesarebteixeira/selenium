package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.PressesKeyCode;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;


public class AberturaPassageiroPage {
	
	static AndroidDriver  driver;

	public AberturaPassageiroPage(AndroidDriver<WebElement> driver) {
		this.driver = driver;
	}

	public void DigitaLogin(String passageiroLogin) {

		System.out.println("entrar : Login ");

		esperaPeloElemento(By.id("com.android.packageinstaller:id/permission_allow_button"), 20);

		driver.findElement(By.id("com.android.packageinstaller:id/permission_allow_button")).click();

		esperaPeloElemento(By.id("com.android.packageinstaller:id/permission_allow_button"), 20);

		if (driver.findElement(By.id("com.android.packageinstaller:id/permission_allow_button")).isDisplayed()) {

			driver.findElement(By.id("com.android.packageinstaller:id/permission_allow_button")).click();

		}

		driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));

		driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);
		driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();

		driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/editTextLogin")).click();

		driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/editTextLogin")).sendKeys(passageiroLogin);

		  driver.pressKeyCode((AndroidKeyCode.KEYCODE_TAB));
	}
	
	public void DigitaSenha(String passageiroSenha) throws Exception {

		driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/editTextPassword")).click();

		driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/editTextPassword")).sendKeys(passageiroSenha);

		// verifica se o keyboard foi apresentado, se sim, retira ele
		hideKeyboard(driver);

		driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_login")).click();

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

		esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_request_taxi"), 30);

		System.out.println("sair : Login ");
	}
	public void esperaPeloElemento(final By by, int esperaEmsegundos) {

		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS)
				.pollingEvery(1, TimeUnit.SECONDS).ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class).withMessage("não encontrei >> " + by)
				.until(new Function<WebDriver, Boolean>() {
					public Boolean apply(WebDriver d) {

						// System.out.println("***" + new
						// SimpleDateFormat("dd/mm/yyyy_hh:mm:ss.SSSXXX").frmat(new
						// Date()));

						return d.findElement(by).isDisplayed();
					}
				});

	}

	public void esperaPeloElementoEnabled(final By by) {
		new FluentWait<AndroidDriver>(driver).withTimeout(59, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
				.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
					public Boolean apply(WebDriver d) {

						return d.findElement(by).isEnabled();
					}
				});

	}

	public void esperaPeloElementoDisabled(final By by, int esperaEmsegundos) {
		new FluentWait<AndroidDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS)
				.pollingEvery(50, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class)
				.until(new Function<WebDriver, Boolean>() {
					public Boolean apply(WebDriver d) {

						return !d.findElement(by).isEnabled();
					}
				});

	}

	public void esperaPeloElementoDesaparecer(final By by, int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class)
				.until(new Function<WebDriver, Boolean>() {
					public Boolean apply(WebDriver d) {

						System.out.println("entreiii");
						return !d.findElement(by).isDisplayed();

					}
				});

	}

	public static void hideKeyboard(AppiumDriver<WebElement> driver) throws Exception {

		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

		try {
			driver.hideKeyboard();
		} catch (Exception e) {
			// Lets ignore, apparently its throwing exception when keyboard was not opened
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

}

package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page;

import io.appium.java_client.android.AndroidDriver;

public class PesquisarEnderecoPage {
	
	private AndroidDriver<?> driver;

	public PesquisarEnderecoPage(AndroidDriver<?> driver) {
		
		
		this.driver = driver;
	}

}

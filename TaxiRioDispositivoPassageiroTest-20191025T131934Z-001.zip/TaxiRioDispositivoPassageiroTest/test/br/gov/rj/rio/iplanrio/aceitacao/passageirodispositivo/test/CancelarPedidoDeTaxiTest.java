package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.test;

import java.util.Map;

import org.testng.annotations.BeforeClass;

import br.gov.rj.rio.iplanrio.aceitacao.infra.BaseAceitacaoTest;
import br.gov.rj.rio.iplanrio.aceitacao.infra.BaseAceitacaoTesteAndroid;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroHomePage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.CancelarPedidoDeTaxiPage;

public class CancelarPedidoDeTaxiTest extends BaseAceitacaoTesteAndroid {

	@Override
	protected void executaPassos(Map<String, String> dado) throws Exception {
		
		if (dado.get("fazLogin").equals("sim")) {
			 
			PassageiroHomePage aberturaPage = new PassageiroHomePage(driver);
			aberturaPage.LoginPage(dado.get("matricula"),  dado.get("senha"), dado.get("exit"), dado.get("resultadoEsperado"));
		}
		
		CancelarPedidoDeTaxiPage cancelarPedidoTaxiPage = new CancelarPedidoDeTaxiPage(driver);
		cancelarPedidoTaxiPage.cancelarSolicitacaoTaxi(dado.get("solicitarCancelamento"), dado.get("exit"));
		
	}

	@Override
	@BeforeClass
	protected void beforeClass() {
		umTestador.carregaUmaPlanilha("CancelarTaxi");
		umTestador.defineSeDeveReportarNoJira(false);
		umTestador.defineSeDeveReportarNoTestlink(false);
		
 
		
	}

}

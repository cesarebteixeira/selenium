package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page;

import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;

import br.gov.rj.rio.iplanrio.aceitacao.infra.exception.AssertionFakeException;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;

public class PassageiroHomePage {

	AndroidDriver<WebElement> driver;

	public PassageiroHomePage(AndroidDriver<WebElement> driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}

	public void DigitaLogin(String passageiroLogin) {

		System.out.println("entrar : Login ");

		esperaPeloElemento(By.id("com.android.packageinstaller:id/permission_allow_button"), 20);

		driver.findElement(By.id("com.android.packageinstaller:id/permission_allow_button")).click();

		esperaPeloElemento(By.id("com.android.packageinstaller:id/permission_allow_button"), 20);

		if (driver.findElement(By.id("com.android.packageinstaller:id/permission_allow_button")).isDisplayed()) {

			driver.findElement(By.id("com.android.packageinstaller:id/permission_allow_button")).click();

		}

		driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));

		driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);
		driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();

		driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/editTextLogin")).click();

		driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/editTextLogin")).sendKeys(passageiroLogin);

		driver.pressKeyCode((AndroidKeyCode.KEYCODE_TAB));
	}
	
	public void DigitaSenha(String passageiroSenha) throws Exception {

		driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/editTextPassword")).click();

		driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/editTextPassword")).sendKeys(passageiroSenha);

		// verifica se o keyboard foi apresentado, se sim, retira ele
		hideKeyboard(driver);

		driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_login")).click();

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

		esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_request_taxi"), 30);

		System.out.println("sair : Login ");
	}

	private void verificaLoginSenhaEmBranco(String matricula, String senha, String resultadoEsperado) throws Exception {

		driver.findElement(By.xpath("//android.widget.EditText[@resource-id='vmLoginLoginId']")).sendKeys(matricula);
		driver.findElement(By.xpath("//android.widget.EditText[@resource-id='vmLoginPasswordId']")).click();
		// verifica se o keyboard foi apresentado, se sim, retira ele
		hideKeyboard(driver);
		driver.findElement(By.xpath("//android.widget.EditText[@resource-id='vmLoginPasswordId']")).sendKeys(senha);
		hideKeyboard(driver);
		driver.findElement(By.xpath("//android.widget.Button[@content-desc='ENTRAR ']")).click();

		if (driver.findElements(By.xpath("//android.view.View[@content-desc=' O e-mail é obrigatório']")).size() > 0) {

			System.out.println("login em branco");
		} else
			assertTrue(false);

		if (driver.findElements(By.xpath("//android.view.View[@content-desc='A senha é obrigatória']")).size() > 0) {

			System.out.println("Senha em branco");
		} else
			assertTrue(false);

	}

	private void verificaEsqueciMinhaSenha(String matricula, String senha, String resultadoEsperado) {

		driver.findElement(By.xpath("//android.widget.Button[@resource-id='forgotPasswordBtnId']")).click();

		esperaPeloElemento(By.xpath("//android.view.View[@content-desc='Esqueci a senha']"), 15);

		if (driver.findElements(By.xpath("//android.view.View[@content-desc='Ainda com dúvidas?']")).size() > 0) {
			System.out.println("tela esqueci minha senha foi apresentado");
		} else
			Assert.assertTrue(true);

	}

	private void verificaLoginInvalido(String email, String senha, String resultadoEsperado) throws Exception {

		driver.findElement(By.xpath("//android.widget.EditText[@resource-id='vmLoginLoginId']")).sendKeys(email);

		driver.findElement(By.xpath("//android.widget.EditText[@resource-id='vmLoginPasswordId']")).click();
		// verifica se o keyboard foi apresentado, se sim, retira ele
		hideKeyboard(driver);
		driver.findElement(By.xpath("//android.widget.EditText[@resource-id='vmLoginPasswordId']")).sendKeys(senha);
		hideKeyboard(driver);
		driver.findElement(By.xpath("//android.widget.Button[@content-desc='ENTRAR ']")).click();

		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		if (driver.findElements(By.xpath("//android.view.View[@index=1 and @content-desc='" + resultadoEsperado + "']"))
				.size() > 0) {
			assertTrue(true);
		} else
			// System.out.println("Resultado esperado era :" + resultadoEsperado + " mas app
			// apresentou :" + driver.findElements(By.xpath("//android.view.View[@index=1
			// and @content-desc=);
			assertTrue(false);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	private void validaExistenciaDeCamposNaTela() {

		// verifica se existe o campo de login
		if (driver.findElements(By.xpath("//android.widget.EditText[@resource-id='vmLoginLoginId']")).size() > 0) {
			System.out.println("*** campo de login exibido");
		}

		if (driver.findElements(By.xpath("//android.widget.EditText[@resource-id='vmLoginPasswordId']")).size() > 0) {
			System.out.println("*** campo de senha exibido");
		}

		if (driver.findElements(By.xpath("//android.widget.Button[@content-desc='ENTRAR ']")).size() > 0) {

			System.out.println("*** campo ENTRAR exibido");
		}

		if (driver.findElements(By.xpath("//android.widget.Button[@content-desc='Esqueci a senha ']")).size() > 0) {

			System.out.println("*** campo Esqueci a senha exibido");
		}

		// if (driver.findElements(By.xpath("//android.view.View[contains(text(),
		// 'Desenvolvido por IPLANRIO • v.:')]")).size()>0){
		//
		// System.out.println("** campo Desenvolvido iplan versão exibido");
		// }

		if (driver.findElements(By.xpath(
				"//android.widget.Button[@content-desc='Esqueci a senha ']/following::android.view.View[@index=2]"))
				.size() > 0) {
			System.out.println("** campo Desenvolvido iplan versão exibido");
		}

	}

	public void LoginTaxistaPage(String matricula, String senha, String exit) throws Exception {

		// verifica se tela de permissão é apresentada, se sim clicar em permitir
		if (driver.findElement(By.xpath(
				"//android.widget.Button[@resource-id='com.android.packageinstaller:id/permission_allow_button']"))
				.isDisplayed()) {
			driver.findElement(By.xpath(
					"//android.widget.Button[@resource-id='com.android.packageinstaller:id/permission_allow_button']"))
					.click();
		}
		esperaPeloElemento(By.xpath("//android.view.View[@index=2]/android.widget.EditText[@index=0]"), 15);

		// verifica se o keyboard foi apresentado, se sim, retira ele
		// hideKeyboard(driver);
		// driver.findElement(By.xpath("//android.view.View[@index=2]/android.widget.EditText[@index=0]")).sendKeys(matricula);

		driver.findElement(By.xpath("//android.view.View[@index=2]")).sendKeys(matricula);
		// verifica se o keyboard foi apresentado, se sim, retira ele
		hideKeyboard(driver);

		driver.findElement(By.xpath("//android.view.View[@index=4]")).click();
		driver.findElement(By.xpath("//android.view.View[@index=4]")).sendKeys(senha);
		// verifica se o keyboard foi apresentado, se sim, retira ele
		hideKeyboard(driver);
		// driver.findElement(By.xpath("//android.widget.EditText[@resource-id='vmLoginPasswordId']")).sendKeys(senha);

		driver.findElement(By.xpath("//android.widget.Button[@index=5]")).click();

		if ("verificarEmail".equals(exit)) {
			throw new AssertionFakeException("Ocorreu uma exceção ");
		}

		if ("verificarSenhaNula".equals(exit)) {
			throw new AssertionFakeException("Ocorreu uma exceção ");
		}

		// *********************************************

		// *********************************************
		if ("verificarSenha".equals(exit)) {
			throw new AssertionFakeException("Ocorreu uma exceção ");
		}

		// *********************************************

	}

	public void esperaPeloElemento(final By by, int esperaEmsegundos) {

		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS)
				.pollingEvery(1, TimeUnit.SECONDS).ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class).withMessage("não encontrei >> " + by)
				.until(new Function<WebDriver, Boolean>() {
					public Boolean apply(WebDriver d) {

						// System.out.println("***" + new
						// SimpleDateFormat("dd/mm/yyyy_hh:mm:ss.SSSXXX").frmat(new
						// Date()));

						return d.findElement(by).isDisplayed();
					}
				});

	}

	public void esperaPeloElementoEnabled(final By by) {
		new FluentWait<AndroidDriver>(driver).withTimeout(59, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
				.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
					public Boolean apply(WebDriver d) {

						return d.findElement(by).isEnabled();
					}
				});

	}

	public void esperaPeloElementoDisabled(final By by, int esperaEmsegundos) {
		new FluentWait<AndroidDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS)
				.pollingEvery(50, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class)
				.until(new Function<WebDriver, Boolean>() {
					public Boolean apply(WebDriver d) {

						return !d.findElement(by).isEnabled();
					}
				});

	}

	public void esperaPeloElementoDesaparecer(final By by, int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS)
				.pollingEvery(500, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class)
				.until(new Function<WebDriver, Boolean>() {
					public Boolean apply(WebDriver d) {

						System.out.println("entreiii");
						return !d.findElement(by).isDisplayed();

					}
				});

	}

	public static void hideKeyboard(AppiumDriver<WebElement> driver) throws Exception {

		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

		try {
			driver.hideKeyboard();
		} catch (Exception e) {
			// Lets ignore, apparently its throwing exception when keyboard was not opened
		}
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

}

package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.test;

import java.util.Map;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import br.gov.rj.rio.iplanrio.aceitacao.infra.BaseAceitacaoTesteAndroid;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroHomePage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroAlteraFormaPagamentoPage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroCancelaSolicitacaoCorridaPage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroCancelaTaxistaPage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroEnviaMensagemTaxistaPage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroEsperaFimCorridaPage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroEsperaTaxiPage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroInformaOrigemEDestinoPage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroRecebeCancelamentoDoTaxistaPage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroRecebeRecusaTaxistaPage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroRecebeValorEAvaliaTaxistaPage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroSolicitaCorridaPage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroSolicitaTaxiPage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroselecionaPercentualPage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.TaxistaCancelaSolicitacaoCorridaPage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.TaxistaRecusaSolicitacaoDeCorridaPage;




@Test
public class PassageiroSolicitaTaxiTest extends BaseAceitacaoTesteAndroid {

	//	private   boolean logarSoUmaVez = true;
	@Override
	protected void executaPassos(Map<String, String> dado) throws Exception {
System.out.println("******* iniciando processo de teste automatizado para o caso de testes " + dado.get("casoDeTeste") + " ***********");

		//poe em backgroud
		//	((AppiumDriver) driver).sendKeyEvent(AndroidKeyCode.Home);

		if (dado.get("fazLogin").equals("sim")) {

			PassageiroHomePage aberturaPage = new PassageiroHomePage(driver);
			aberturaPage.LoginPage(dado.get("matricula"), dado.get("senha"), dado.get("exit"), dado.get("resultadoEsperado"));
		}

		PassageiroInformaOrigemEDestinoPage passageiroInformaOrigemEDestinoPage = new PassageiroInformaOrigemEDestinoPage(driver);
		passageiroInformaOrigemEDestinoPage.informaEnderecoOrigem(dado.get("informaOrigem") );
	 	passageiroInformaOrigemEDestinoPage.informaEnderecoDestino(dado.get("informaDestino"));
		
		PassageiroSolicitaCorridaPage passageiroSolicitaCorridaPage = new PassageiroSolicitaCorridaPage(driver);
		passageiroSolicitaCorridaPage.solicitaCorrida(dado.get("taxistaNoPerimetro1500m"));
		
		PassageiroAlteraFormaPagamentoPage passageiroAlteraFormaPagamentoPage = new PassageiroAlteraFormaPagamentoPage(driver);
		passageiroAlteraFormaPagamentoPage.selecionaFormaPagamento(dado.get("tipoPagamento"));
		
		
		PassageiroselecionaPercentualPage passageiroselecionaPercentualPage = new PassageiroselecionaPercentualPage(driver);
		passageiroselecionaPercentualPage.passageiroSelecionaPercentual(dado.get("percetualDesconto"), dado.get("taxistaDisponivel"));	
		
		TaxistaRecusaSolicitacaoDeCorridaPage taxistaRecusaSolicitacaoDeCorridaPage = new TaxistaRecusaSolicitacaoDeCorridaPage(driver);
		taxistaRecusaSolicitacaoDeCorridaPage.taxistaRecusaSolicitacao(dado.get("taxistaRecusouSolicitacaoCorrida"));
		
		
		TaxistaCancelaSolicitacaoCorridaPage taxistaCancelaSolicitacaoCorridaPage = new TaxistaCancelaSolicitacaoCorridaPage(driver);
		taxistaCancelaSolicitacaoCorridaPage.passageiroRecebeMensagemQueTaxistaCancelouSolicitacao(dado.get("taxistaCancelouSolicitacao"), dado.get("passageiroVerificaSeApareceuEstaMensagem"));
		
		PassageiroCancelaSolicitacaoCorridaPage passageiroCancelaSolicitacaoCorridaPage = new PassageiroCancelaSolicitacaoCorridaPage(driver);
		passageiroCancelaSolicitacaoCorridaPage.cancelarSolicitacaoCorrida(dado.get("passageiroCancelarSolicitacaoCorrida"), dado.get("passageiroConfirmaCancelarSolicitacaoCorrida"));
		
		//verificar parece duplicidade
	//	PassageiroCancelaTaxistaPage passageiroCancelaTaxistaPage = new PassageiroCancelaTaxistaPage(driver);
	//	passageiroCancelaTaxistaPage.cancelarSolicitacaoCorrida(dado.get("cancelarSolicitacaoCorrida"), dado.get("confirmaCancelamentoCorrida"));
		
		PassageiroRecebeCancelamentoDoTaxistaPage passageiroRecebeCancelamentoDoTaxistaPage = new PassageiroRecebeCancelamentoDoTaxistaPage(driver);
		passageiroRecebeCancelamentoDoTaxistaPage.passageiroInformadoCancelamento(dado.get("taxistaCancelouSolicitacao"));
		
		PassageiroRecebeRecusaTaxistaPage passageiroRecebeRecusaTaxistaPage = new PassageiroRecebeRecusaTaxistaPage(driver);
		passageiroRecebeRecusaTaxistaPage.passageiroRecebeRecusaTaxista(dado.get("taxistaRecusouSolicitacaoCorrida"));
		
	 	PassageiroEnviaMensagemTaxistaPage passageiroEnviaMensagemTaxistaPage = new PassageiroEnviaMensagemTaxistaPage(driver);
	 	passageiroEnviaMensagemTaxistaPage.enviaMensagemParaTaxista(dado.get("enviarMensagem"), dado.get("numeroMensagem"),  dado.get("taxistaResponde"), dado.get("quemEnviaMensagemPrimeiro"), dado.get("passageiroResponde"),
	 			dado.get("passageiroEnviaOutraMensagem"), dado.get("taxistaEnviaOutraMensagem"));
	 
 		PassageiroEsperaTaxiPage passageiroEsperaTaxiPage = new PassageiroEsperaTaxiPage(driver);
 		passageiroEsperaTaxiPage.passageiroEsperaTaxi();
		
				
		PassageiroEsperaFimCorridaPage passageiroEsperaFimCorridaPage = new PassageiroEsperaFimCorridaPage(driver);
		passageiroEsperaFimCorridaPage.passageiroEsperaFimCorrida();
		
		PassageiroRecebeValorEAvaliaTaxistaPage  passageiroRecebeValorEAvaliaTaxistaPage = new PassageiroRecebeValorEAvaliaTaxistaPage(driver);
		passageiroRecebeValorEAvaliaTaxistaPage.recebeValorEAvaliaTaxista(dado.get("avaliaTaxista"), dado.get("enviaComentario"), dado.get("comentario"), dado.get("avaliaTaxistaEstrelas"),
				dado.get("informaOrigem"), dado.get("informaDestino"), dado.get("bandeiraEmUso"), dado.get("nomeTaxista"), dado.get("marcaPlaca"));
		
				
		System.out.println("Fim do caso de teste : " + dado.get("casoDeTeste"));

//		PassageiroSolicitaTaxiPage passageiroSolicitaTaxiPage = new PassageiroSolicitaTaxiPage(driver);
		
		//	solicitaTaxiPage.selecionaEnderecoOrigem(dado.get("localPartida"));
		//	solicitaTaxiPage.clicarBotaoEscolherOrigem();
		//	solicitaTaxiPage.selecionaEnderecoDestino(dado.get("localDestino"));
		//	solicitaTaxiPage.clicarBotaoEscolherDestino();
	//	passageiroSolicitaTaxiPage.selecionaPedirTaxi(dado.get("temTaxiDisponivel"), dado.get("localPartida"), 
	//			dado.get("localDestino"),dado.get("alteradoEnderecoDePartidaGps"), dado.get("enviarMensagem"),
	//			dado.get("numeroMensagem"), dado.get("tipoDeResposta"), dado.get("exit"), dado.get("resultadoEsperado"));

// 
//



	}



	@BeforeClass
	@Override
	protected void beforeClass() {

		umTestador.carregaUmaPlanilha("PassageiroSolicitaCorrida");
		umTestador.defineSeDeveReportarNoJira(false);
		umTestador.defineSeDeveReportarNoTestlink(false);


	}

}

package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;

import br.gov.rj.rio.iplanrio.aceitacao.infra.exception.AssertionFakeException;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;

public class PassageiroCancelaSolicitacaoCorridaPage {



	AndroidDriver<?> driver;


	public PassageiroCancelaSolicitacaoCorridaPage(AndroidDriver<?> driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}


	public void cancelarSolicitacaoCorrida(String passageiroCancelarSolicitacaoCorrida, String passageiroConfirmaCancelarSolicitacaoCorrida
			) throws AssertionFakeException {

		System.out.println("Entrar : cancelarSolicitacaoCorrida");
		
	
		
		
		

		if (!passageiroCancelarSolicitacaoCorrida.equals("nãoTesta")) {	
			driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));			  
			driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);			 
			driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();

			//cancela solicitação de corrida

			esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_cancel_race_drive_on_the_way"), 30);
			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_cancel_race_drive_on_the_way")).click();
			//confirma cancelamento
			if (passageiroConfirmaCancelarSolicitacaoCorrida.equals("sim")) {
			//	driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));
			//	driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);
			//	driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();
				esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/buttons_yes"), 30);
				driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/buttons_yes")).click();
			}else  {   //if (confirmaCancelarSolicitacaoCorrida.equals("não"))
				esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/buttons_no"), 30);
				driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/buttons_no")).click();

			}


			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			while (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/tv_msg_wait")).size()  > 0) {
				//aguardando terminar o aguarde...
			}
			//dispensa a corrida 
			 throw new AssertionFakeException("Passageiro cancelou a solicitação de corrida");
		} System.out.println("Não será testada : cancelarSolicitacaoCorrida");
		System.out.println("sair : cancelarSolicitacaoCorrida");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);


	}


	public void esperaPeloElemento(final By by, int esperaEmsegundos) {

		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(250, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
		.withMessage("não encontrei >> " + by).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				// System.out.println("***" + new
				// SimpleDateFormat("dd/mm/yyyy_hh:mm:ss.SSSXXX").frmat(new
				// Date()));

				return d.findElement(by).isDisplayed();
			}
		});

	}

	public void esperaPeloElementoEnabled(final By by) {
		new FluentWait<WebDriver>(driver).withTimeout(59, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return d.findElement(by).isEnabled();
			}
		});

	}



	public void esperaPeloElementoDisabled(final By by,int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(50, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !d.findElement(by).isEnabled();
			}
		});

	}

	public void esperaPeloElementoDesaparecer(final By by, int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(250, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !(d.findElement(by).isDisplayed());
			}
		});

	}

}
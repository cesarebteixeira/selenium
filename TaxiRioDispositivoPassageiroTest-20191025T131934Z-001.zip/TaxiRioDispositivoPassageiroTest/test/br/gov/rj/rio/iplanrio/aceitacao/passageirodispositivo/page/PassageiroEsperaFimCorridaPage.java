package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;

public class PassageiroEsperaFimCorridaPage {
	AndroidDriver<?> driver;


	public PassageiroEsperaFimCorridaPage(AndroidDriver<?> driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}


	public void passageiroEsperaFimCorrida() throws InterruptedException {
		
		Thread.sleep(2000);
		
		System.out.println("Entrar : passageiroEsperaFimCorrida");
		
		driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));			  
		driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);			 
		driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();
		
		//aguarda tela de avaliação do taxista
		esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_dismiss_rating"), 600);
		
		driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));			  
		driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);			 
		driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();
		
		System.out.println("Sair : passageiroEsperaFimCorrida");
	//	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	}
	public void esperaPeloElemento(final By by, int esperaEmsegundos) {

		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(250, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
		.withMessage("não encontrei >> " + by).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				// System.out.println("***" + new
				// SimpleDateFormat("dd/mm/yyyy_hh:mm:ss.SSSXXX").frmat(new
				// Date()));

				return d.findElement(by).isDisplayed();
			}
		});
		System.out.println("Sair : passageiroEsperaFimCorrida");

	}

	public void esperaPeloElementoEnabled(final By by) {
		new FluentWait<WebDriver>(driver).withTimeout(59, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return d.findElement(by).isEnabled();
			}
		});

	}



	public void esperaPeloElementoDisabled(final By by,int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(50, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !d.findElement(by).isEnabled();
			}
		});

	}

	public void esperaPeloElementoDesaparecer(final By by, int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(250, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !(d.findElement(by).isDisplayed());
			}
		});

	}

}

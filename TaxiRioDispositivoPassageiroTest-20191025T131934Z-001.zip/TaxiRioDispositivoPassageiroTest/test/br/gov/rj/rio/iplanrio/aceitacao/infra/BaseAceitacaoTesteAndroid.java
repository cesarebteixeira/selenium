package br.gov.rj.rio.iplanrio.aceitacao.infra;

import static org.testng.AssertJUnit.assertTrue;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import br.gov.rj.rio.iplanrio.aceitacao.infra.exception.AssertionFakeException;
import br.gov.rj.rio.iplanrio.aceitacao.util.jira.JiraInstance;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public abstract class BaseAceitacaoTesteAndroid {

	protected Testador umTestador;
//taxirio	protected AndroidDriver<?> driver;
	protected static AndroidDriver<?> driver;

	@Test
	public void ExecutaListaDeCasosDeUso() throws Exception {

		System.out.println("Estou dentro do ExecutaListaDeCasosDeUso do Android");



		List<Map<String, String>> dadosDaPlanilha = umTestador.getDadosDaPlanilha();
		for (Map<String, String> dado : dadosDaPlanilha) {
			System.out.println("executando caso de teste >>>>>>>>>> " + dado.get("casoDeTeste") +"  <<<<<<<<");


	 		if (dado.get("fazLogin").equals("sim")){

	 			driver = umTestador.getAndroidDriver();

	 		}  		
			// 	driver = umTestador.getAndroidDriver();
			
	//		if (dado.get("nuvem").equals("sim")) {
	//			driver = umTestador.getAndroidDriverNuvem();
				
	//		}

			try {

				this.executaPassos(dado);
				umTestador.capturaMensagensDaTela();
				this.verificaResultado(dado);
				umTestador.reportaQuePassouNoTeste(dado, driver);

			} catch (AssertionFakeException e) {

				System.out.println("Uma erro esperado ocorreu.");
				try {

					umTestador.capturaMensagensDaTela();
					this.verificaResultado(dado);
				} catch (AssertionError e2) {
					umTestador.reportaErroNaAplicacao(e2, dado, driver);
				} catch (Exception e2) {

					umTestador.reportaErroNaEstruturaDoTeste(e2, dado, driver);
				}

			} catch (AssertionError e) {

				umTestador.reportaErroNaAplicacao(e, dado, driver);
			} catch (Exception e) {


				umTestador.reportaErroNaEstruturaDoTeste(e, dado, driver);
			} finally {

				//	driver.quit();
				//ct	driver.quit();
				if (dado.get("quit").equals("Sim")){ //visando não ficar fazendo login acada linha lida da planilha.
					driver.quit();
				};
			}
		}

		umTestador.geraRelatorioDeEvidencias();
	}

	private void verificaResultado(Map<String, String> dado) {


		//android - enquanto não consigo resilver o problema de capturar
		//todo o texto da tela, vamos improvisar. Pulando o teste final

		//	if ("sim".equals(dado.get("verificaResultadoEsperado"))){


		if("*".equals(dado.get("resultadoEsperadoPassageiro"))){	
			System.out.println("***** não verifica resultado esperado, pois não há mensagem");
		}else
			if(!" ".equals(dado.get("resultadoEsperado"))){	
				String todoTextoDaPagina = driver.getPageSource();
				//	String todoTextoDaPagina= driver.findElement(By.xpath("//android.view.View")).getText();
				//	System.out.println("*" + todoTextoDaPagina);

				System.out.println("*** " + driver.getPageSource());


				String message = "O valor '" + dado.get("resultadoEsperado") + "' não foi encontrado na página.";
				assertTrue(message, StringUtils.contains(todoTextoDaPagina, dado.get("resultadoEsperadoPassageiro")));

			}
		//}
	}

	protected abstract void executaPassos(Map<String, String> dado) throws Exception;

	@BeforeClass
	protected abstract void beforeClass();

	@BeforeTest
	public void beforeTest() {

		umTestador = new Testador();

	}

	@AfterTest
	public void afterTest() throws IOException {

		JiraInstance.getRestClient().close();

	}

	@AfterClass
	public void afterClass() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		System.out.println("*** fim *** : " + dateFormat.format(date));

	}

}

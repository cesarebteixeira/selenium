package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;

public class PassageiroEsperaTaxiPage {

	private AndroidDriver<?> driver;

	public PassageiroEsperaTaxiPage(AndroidDriver<?> driver) {

		this.driver = driver;
	}

	public void passageiroEsperaTaxi() throws InterruptedException {

		System.out.println("Entrar : passageiroEsperaTaxi");
		Thread.sleep(1000);
		System.out.println("11");
		driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));	
		System.out.println("12");
		driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);		
		System.out.println("13");
		driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();
		System.out.println("14");
		Thread.sleep(1000);
		System.out.println("15");
			// espera o taxista aceitar if taxista aceitaCorrida ou seja que seja disponibilizado aqui no passageiro o botão de mensageria

	
		System.out.println("Sair : passageiroEsperaTaxi");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
	public void esperaPeloElementoNaoEmpty(final By by, int esperaEmsegundos) {

		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(100, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
		.withMessage("não encontrei >> " + by).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !d.findElements(by).isEmpty();
			//	return d.findElement(by).isDisplayed();
			}
		});

	}

	public void esperaPeloElemento(final By by, int esperaEmsegundos) {

		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(500, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
		.withMessage("não encontrei >> " + by).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				// System.out.println("***" + new
				// SimpleDateFormat("dd/mm/yyyy_hh:mm:ss.SSSXXX").frmat(new
				// Date()));

				return d.findElement(by).isDisplayed();
			}
		});

	}

	public void esperaPeloElementoEnabled(final By by) {
		new FluentWait<WebDriver>(driver).withTimeout(59, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return d.findElement(by).isEnabled();
			}
		});

	}

	
}

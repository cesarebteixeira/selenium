package br.gov.rj.rio.iplanrio.aceitacao.infra.exception;

public class AssertionFakeException extends Exception {
	
	private static final long serialVersionUID = 8406515974110679426L;

	public AssertionFakeException(String msg) {

		super(msg);
	}

}

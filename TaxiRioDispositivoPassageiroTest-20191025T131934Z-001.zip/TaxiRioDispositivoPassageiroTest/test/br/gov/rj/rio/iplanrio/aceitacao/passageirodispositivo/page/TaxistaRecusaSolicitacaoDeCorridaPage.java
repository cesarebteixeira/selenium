package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.Assert;

import com.google.common.base.Function;

import br.gov.rj.rio.iplanrio.aceitacao.infra.exception.AssertionFakeException;
import io.appium.java_client.android.AndroidDriver;
 

public class TaxistaRecusaSolicitacaoDeCorridaPage {
	
	AndroidDriver<?> driver;
	
	public TaxistaRecusaSolicitacaoDeCorridaPage(AndroidDriver<?> driver) {
		
		this.driver = driver;
	}

	public void taxistaRecusaSolicitacao(String taxistaRecusouSolicitacaoCorrida) throws AssertionFakeException {
		
		
		if (!taxistaRecusouSolicitacaoCorrida.equals("nãoTesta")) {
			
			if (taxistaRecusouSolicitacaoCorrida.equals("sim")) {
			
			//como taxista recusou a solicitação passageiro deve aguardar até 2 minutos, pois haverá outro broadcast e ao terminar a tela do passageiro
			// deve retornar para tela de endereço de origem X destino x Avançar
			// vou aguardar o botão Avançar aparec pois a barra de amostragem de tempo leva 1 minuto para sai do modo de espera por taxista
				
		
			 esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_request_taxi"), 61);
			
			Assert.assertTrue(true);
			
		     throw new AssertionFakeException("Ocorreu uma exceção esperada ");
			}
		}
		
	}

	public void esperaPeloElemento(final By by, int esperaEmsegundos) {

		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(100, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
		.withMessage("não encontrei >> " + by).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				// System.out.println("***" + new
				// SimpleDateFormat("dd/mm/yyyy_hh:mm:ss.SSSXXX").frmat(new
				// Date()));

				return d.findElement(by).isDisplayed();
			}
		});

	}

	public void esperaPeloElementoEnabled(final By by) {
		new FluentWait<WebDriver>(driver).withTimeout(59, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return d.findElement(by).isEnabled();
			}
		});

	}

	public void esperaPeloElementoDisabled(final By by,int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(50, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !d.findElement(by).isEnabled();
			}
		});

	}

	public void esperaPeloElementoDesaparecer(final By by, int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !(d.findElement(by).isDisplayed());
			}
		});

	}


}

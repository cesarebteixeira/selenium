package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page;



import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Sleeper;

import com.google.common.base.Function;

import br.gov.rj.rio.iplanrio.aceitacao.infra.exception.AssertionFakeException;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class PassageiroSolicitaTaxiPage {

	private AndroidDriver<?> driver;
	public PassageiroSolicitaTaxiPage(AndroidDriver<?> driver) {
		this.driver = driver;

	}

	public void selecionaEnderecoOrigem(String localPartida) throws Exception{


		System.out.println("e");
		if (localPartida.isEmpty()){ //isso indica que o endereço de partida, capturada pelo GPS, será mantida

		}else { //o endereço a ser utilizado deve ser da planilha


			System.out.println("***" + driver.getPageSource());
			esperaPeloElemento(By.xpath("//android.widget.EditText[@resource-id='vmSolicitarTaxiOriginId' and @index=0]"), 15);


			//input endereco de origem lido da planilha
			driver.findElement(By.xpath("//android.widget.EditText[@resource-id='vmSolicitarTaxiOriginId' and @index=0]")).click();
			System.out.println("f");

			esperaPeloElemento(By.xpath("//android.view.View[@content-desc='Pesquisar Origem']"),15);
			System.out.println("g");
			//		driver.findElement(By.xpath("//android.widget.EditText[@index=1]")).click();

			//tem situações que o endereço de origem pego pelo gps não é passado para o campo de pesquisa

			String recebeTexto = driver.findElement(By.xpath("//android.widget.EditText[@index=1]")).getText();

			if (recebeTexto.equals("Pesquisar")){			

				//	driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				//	System.out.println("h");
				//	if (driver.findElements(By.xpath("//android.widget.EditText[@text='Pesquisar']")).size()>0){
				System.out.println("i");
				driver.findElement(By.xpath("//android.widget.EditText[@index=1]")).sendKeys(localPartida);
				System.out.println("j");
				//	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				System.out.println("k");
			} else {
				System.out.println("l");
				//	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				System.out.println("m");
				//clicar no X
				driver.findElement(By.xpath("//android.widget.EditText[@index=1]/following-sibling::android.view.View[@index=2]")).click();
				System.out.println("n");
				esperaPeloElemento(By.xpath("//android.widget.EditText[@text='Pesquisar']"), 15);

				System.out.println("o");
				driver.findElement(By.xpath("//android.widget.EditText[@index=1]")).sendKeys(localPartida);
			}
			System.out.println("p");
			//verifica se o keyboard foi apresentado, se sim, retira ele
			//*	hideKeyboard(driver);
			esperaPeloElemento(By.xpath("//android.view.View[contains (@content-desc,'"+ localPartida +   "' ) ]"),15);
			System.out.println("q");
			driver.findElement(By.xpath("//android.view.View[contains (@content-desc,'"+ localPartida +   "' ) ]")).click();
			System.out.println("r");
			esperaPeloElemento(By.xpath("//android.view.View[@content-desc='' and @index=0]"), 15);
			System.out.println("s");
			//verifica se o keyboard foi apresentado, se sim, retira ele
			hideKeyboard(driver);
			esperaPeloElemento(By.xpath("//android.widget.Button[@content-desc='Escolher Origem ' and @index=0]"),15);
			System.out.println("t");
		}
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

	}

	public void selecionaEnderecoDestino(String localDestino) throws Exception{

		//espera pelo elemento "Local de origem"
		System.out.println("a");
		esperaPeloElemento(By.xpath("//android.widget.EditText[@resource-id='vmSolicitarTaxiOriginId']"),30);
		System.out.println("b");
		//aguarda o campo do endereço de origem ser preenchido com base na gps
		esperaPeloElementoNaoEmpty(By.xpath("//android.widget.EditText[@resource-id='vmSolicitarTaxiOriginId']"), 30);
		System.out.println("c");
		//clicar no simbolo de localização (circulo negro)
		driver.findElement(By.xpath("//android.widget.Button[@resource-id='locateButtonId' and @content-desc=' ']")).click();
		System.out.println("d");
		//******

		//esperar pelo local de destibo ser preenchido
		//espera....
		System.out.println("1");
		esperaPeloElemento(By.xpath("//android.widget.EditText[@resource-id='vmSolicitarTaxiDestinyId']"),30);
		System.out.println("2");
		driver.findElement(By.xpath("//android.widget.EditText[@resource-id='vmSolicitarTaxiDestinyId']")).click();
		//verifica se o keyboard foi apresentado, se sim, retira ele
		hideKeyboard(driver);

		System.out.println("2.1");	

		try {
			driver.findElement(By.xpath("android.view.View[@index=2]")).click();
		} catch (Exception e) {
			// TODO: handle exception
		}



		System.out.println("3");
		esperaPeloElemento(By.xpath("//android.view.View[@content-desc='Pesquisar Destino']"), 5);
		System.out.println("4");

		driver.findElement(By.xpath("//android.widget.EditText[@index=1]")).click();
		//verifica se o keyboard foi apresentado, se sim, retira ele
		hideKeyboard(driver);
		System.out.println("5");
		driver.findElement(By.xpath("//android.widget.EditText[@text='Pesquisar']")).sendKeys(localDestino);
		System.out.println("6");
		//verifica se o keyboard foi apresentado, se sim, retira ele
		hideKeyboard(driver);
		driver.findElement(By.xpath("//android.view.View[@index=0]")).click();
		//verifica se o keyboard foi apresentado, se sim, retira ele
		hideKeyboard(driver);
		System.out.println("7");
		//espera pelo endereco com ticket
		esperaPeloElemento(By.xpath("//android.view.View[@content-desc='' and @index=0]"), 30);
		System.out.println("8");

		//verifica se o keyboard foi apresentado, se sim, retira ele
		hideKeyboard(driver);
		//	driver.findElement(By.xpath("//android.view.View[@index=0]")).click();
		//	driver.findElement(By.xpath("//android.view.View[contains (@content-desc,'"+ localDestino +   "' ) ]")).click();
		esperaPeloElemento(By.xpath("//android.widget.Button[@content-desc='Escolher Destino ']"),15);
		System.out.println("9");

		//button "Escolher Destino"
		//	driver.findElement(By.xpath("//android.widget.Button[@content-desc='Escolher Destino ']")).click();		

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

	}
	public void selecionaPedirTaxi(String temTaxiDisponivel, String localPartida, String localDestino,String alteradoEnderecoDePartidaGps, 
			String enviarMensagem, String numeroMensagem, String tipoDeResposta,
			String exit, String resultadoEsperado) throws Exception {

		Thread.sleep(2000);
		System.out.println("1");




		System.out.println("4");


		System.out.println("6");
		//	if (driver.findElements(By.className("android.widget.LinearLayout")).size()>0){
		System.out.println("7");
		//		esperaPeloElementoDesaparecer(By.className("android.widget.LinearLayout"), 50);
		//	}
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		System.out.println("8");


		driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));
		System.out.println("9");  
		driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);
		System.out.println("10");
		driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();
		System.out.println("11");

		//**************************************************
		//clicar no botão avançar
		driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_request_taxi")).click();
		System.out.println("14");

		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

		while (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/tv_msg_wait")).size()  > 0) {
			//aguardando terminar o aguarde...

		}
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);


		driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));

		driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);

		driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();

		// SELECIONA  10%  ***************************************
		driver.findElement(By.xpath("//android.widget.LinearLayout[@index=1]/android.widget.Button[@text='OK']	")).click();

		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		while (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/tv_msg_wait")).size()  > 0) {
			//aguardando terminar o aguarde...

		}
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		// espera o taxista aceiar if taxista aceitaCorrida ou seja que seja disponibilizado aqui no passageiro o botão de mensageria

		esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_msg_driver_on_the_way"), 60);


		/*  aqui será colocado as trocas de mensagens entre passageiro e taxista	  */	

		if (enviarMensagem.equals("sim")) {	
			esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_msg_driver_on_the_way"),5);
			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_msg_driver_on_the_way")).click();

			esperaPeloElemento(By.xpath("//android.widget.RadioButton[@index=0]"), 5);
			trocarMensagemEntreTaxistaEPassageiro(numeroMensagem, tipoDeResposta);
		}





		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		if (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/tv_msg_wait")).size()  > 0) {
			while (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/tv_msg_wait")).size()  > 0) {
				//aguardando terminar o aguarde...

			}

		}
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		//	 esperaPeloElemento(By"corrida em andamento", esperaEmsegundos);

		//aguarda tela de avaliação do taxista
		esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_dismiss_rating"), 60);

		driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_dismiss_rating")).click();


		Thread.sleep(2000); // espera para recomeçar 


		//Se taxista Recusa corrida


		/*


		//espera pelo elemento "Local de origem" e atualização do endereço do GPS(circulo negro)

		esperaPeloElemento(By.xpath("//android.widget.EditText[@resource-id='vmSolicitarTaxiOriginId']"),30);

		//aguarda o campo do endereço de origem ser preenchido com base na gps
		esperaPeloElementoNaoEmpty(By.xpath("//android.widget.EditText[@resource-id='vmSolicitarTaxiOriginId']"), 30);


		//clicar no simbolo de localização (circulo negro)
		driver.findElement(By.xpath("//android.widget.Button[@resource-id='locateButtonId' and @content-desc=' ']")).click();


		//verifica se o endereço destino está preenchido, se tiver 

		//executa CT 113 Ct112nCT 114 Ct115 especificado no testlink
		if ("ct113".equals(exit)) {
			System.out.println("*** ct113 ***");
			selecionaEnderecoOrigem (localPartida);
			cancelarPesquisa();
			//		cancelaPesquisaEnderecoOrigem( localPartida);
			throw new AssertionFakeException("Ocorreu uma exceção ");
		}

		// *********************************************

		//executa CT 103 especificado no testlink
		if ("ct103".equals(exit)) {
			System.out.println("*** ct103 ***");
			selecionaEnderecoDestino( localDestino);
			clicarBotaoEscolherDestino();
			throw new AssertionFakeException("Ocorreu uma exceção ");
		}

		// 


		//executa CT 10 especificado no testlink
		if ("ct10".equals(exit)) {
			selecionaEnderecoDestino( localDestino);
			clicarBotaoEscolherDestino();
			passageiroApagaDestino();
			throw new AssertionFakeException("Ocorreu uma exceção ");
		}



		/*
		if (localPartida.isEmpty()){ //isso indica que o endereço de partida, capturada pelo GPS, será mantida
			//clicar no circulo negro para aproximar o endereço
			driver.findElement(By.xpath("//android.widget.Button[@content-desc='locateButtonId']")).click();
		}else {//o endereço de partida será outro e o passageiro deve pesquisar no app
			driver.findElement(By.xpath("//android.widget.EditText[@resource-id='vmSolicitarTaxiOriginId']")).click();														



			pesquisaPorLocalDePartida(localPartida);
		}		//informa endereço e app faz pesquisa e apresenta  os possiveis endereços . Usuário seleciona endereço

		 */

		/*
		//selecionar o destino e pesquisar o endereço de destino
		driver.findElement(By.xpath("//android.widget.EditText[@resource-id='vmSolicitarTaxiDestinyId']")).click();
		//pesquisa quais os possiveis endereços apresentados e seleciona o desejado
		if (!localDestino.isEmpty()){
			//pesquisaPorLocalDestino( localDestino);
			selecionaEnderecoDestino( localDestino);
		}


		//solicita taxi com o endereço de partida selecionado pelo gps e sem preencher destino
		//		driver.findElement(By.xpath("//android.widget.Button[@content-desc='Solicitar Taxi.Rio ']")).click();



		 */


		//verificar 3 situações
		//1 - ao clicar no botão PEDIR TAXI:
		//    * título do botão PEDIR TAXI deve mudar para CANCELAR TAXI
		//    * passageiro recebe msg "Encontrando melhores taxistas perto de você."
		//    se não houver taxista, informar:
		//    	"Infelizmente não encontramos Taxista para atender seu pedido. Por favor tente novamente.






	}


	private void trocarMensagemEntreTaxistaEPassageiro(String numeroMensagem, String tipoDeResposta) {

		System.out.println("mensagem número "+ numeroMensagem);

		esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/edit_message"), 5);
		driver.findElement(By.xpath("//android.widget.RadioButton[@index= " + numeroMensagem + "]")).click();

		if (!numeroMensagem.equals("5")) {

			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_message")).click(); //Enviar
			//espera passageiro responder
			//faz todas as mensagens entre taxista e passageiro
			esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/id_message"), 20);// text: OK, Entendi
			esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message"), 20);
			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message")).click();
			//	driver.findElement(By.xpath("//android.widget.Button[@index=3 and @text='Fechar']")).click(); //text : Fechar
			//esperar botão nova mensagem
		}else { //enviando mensagem escrita
			if (tipoDeResposta.equals("Outra resposta")) {
				driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/edit_message")).sendKeys("Sr. Motorista estou lhe aguradando a muito tempo, o que houve?");

				driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_message")).click();
				
				esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it"), 20); //espera por outra resposta
				driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it")).click();
			}else { //OK entendi
				driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/edit_message")).sendKeys("Sr. Motorista estou lhe aguradando a muito tempo, o que houve?");
				driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_message")).click(); //Enviar
				
				esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/id_message"), 20);// text: OK, Entendi
				esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message"), 20);
				driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message")).click();
			}

		}
	//	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

	}

	private void passageiroApagaDestino() {

		driver.findElement(By.xpath("//android.widget.EditText[@resource-id='vmSolicitarTaxiDestinyId']")).clear();

	}

	private void cancelaPesquisaEnderecoOrigem(String localPartida) throws Exception {

		selecionaEnderecoOrigem(  localPartida);

	}



	public boolean enquantoEnderecoOrigemEstiverVazio() throws InterruptedException{

		if (driver.findElements(By.xpath("//android.widget.EditText[@resource-id='vmSolicitarTaxiOriginId']")).isEmpty()){

			//	Thread.sleep(200);
			return false;

		}else return true;

	}

	/*
	private void pesquisaPorLocalDestino(String localDestino) {

		//esperar pelo local de origem ser preenchido
		//espera....

		esperaPeloElemento(By.xpath("//android.widget.EditText[@resource-id='vmSolicitarTaxiDestinyId']"),30);

		driver.findElement(By.xpath("//android.widget.EditText[@resource-id='vmSolicitarTaxiDestinyId']")).click();
		driver.findElement(By.xpath("//android.widget.EditText[@resource-id='vmSolicitarTaxiDestinyId']")).sendKeys(localDestino);

		driver.findElement(By.xpath("//android.view.View[@index=0]")).click();
		esperaPeloElemento(By.xpath("//android.widget.Button[@content-desc='Escolher Destino ']"),30);

		//button "Escolher Destino"
		driver.findElement(By.xpath("//android.widget.Button[@content-desc='Escolher Destino ']")).click();		


	}

	 */
	public static void hideKeyboard(AppiumDriver<?> driver) throws Exception {
		try {
			driver.hideKeyboard();
		} catch (Exception e) {
			//Lets ignore, apparently its throwing exception when keyboard was not opened
		}
	}

	public void clicarBotaoEscolherOrigem() {

		//button "Escolher Origem"

		driver.findElement(By.xpath("//android.widget.Button[@content-desc='Escolher Origem ' and @index=0]")).click();	



	}

	public void clicarBotaoEscolherDestino() throws Exception {

		//verifica se o keyboard foi apresentado, se sim, retira ele
		hideKeyboard(driver);

		//button "Escolher Destino"


		driver.findElement(By.xpath("//android.widget.Button[@content-desc='Escolher Destino ' and @index=0]")).click();	


	}

	public void cancelarPesquisa() throws AssertionFakeException {

		driver.findElement(By.xpath("//android.widget.Button[@content-desc='Cancelar ']")).click();
		//	throw new AssertionFakeException("Ocorreu uma exceção ");

	}

	/*

	private void pesquisaPorLocalDePartida(String localPartida) {
		esperaPeloElemento(By.xpath("//android.widget.EditText[@index=1]"),15);
		driver.findElement(By.xpath("//android.view.View[@index=2 and @content-desc=' ']")).click();
		driver.findElement(By.xpath("//android.widget.EditText[@index=1]")).sendKeys(localPartida);
		esperaPeloElemento(By.xpath("//android.view.View[contains (@content-desc,'"+ localPartida +   "' ) ]"),15);
		driver.findElement(By.xpath("//android.view.View[contains (@content-desc,'"+ localPartida +   "' ) ]")).click();
		esperaPeloElemento(By.xpath("//android.widget.Button[@content-desc='Escolher Origem ' and @index=0]"),15);

		//button "Escolher Origem"
		driver.findElement(By.xpath("//android.widget.Button[@content-desc='Escolher Origem ' and @index=0]")).click();		
	}
	 */
	public void esperaPeloElementoNaoEmpty(final By by, int esperaEmsegundos) {

		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(100, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
		.withMessage("não encontrei >> " + by).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {


				String conteudoLocalPartida = d.findElement(by).getText();
				//	String x=	driver.findElement(By.xpath("//android.widget.EditText[@resource-id='vmSolicitarTaxiOriginId']")).getText();
				if (!conteudoLocalPartida.equals("")){
					return true;
				}else
					return false;


				//return !d.findElements(by).isEmpty();

			}
		});

	}

	public void esperaPeloElemento(final By by, int esperaEmsegundos) {

		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(250, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
		.withMessage("não encontrei >> " + by).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				// System.out.println("***" + new
				// SimpleDateFormat("dd/mm/yyyy_hh:mm:ss.SSSXXX").frmat(new
				// Date()));

				return d.findElement(by).isDisplayed();
			}
		});

	}

	public void esperaPeloElementoEnabled(final By by) {
		new FluentWait<WebDriver>(driver).withTimeout(59, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return d.findElement(by).isEnabled();
			}
		});

	}



	public void esperaPeloElementoDisabled(final By by,int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(50, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !d.findElement(by).isEnabled();
			}
		});

	}

	public void esperaPeloElementoDesaparecer(final By by, int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(250, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !(d.findElement(by).isDisplayed());
			}
		});

	}





}

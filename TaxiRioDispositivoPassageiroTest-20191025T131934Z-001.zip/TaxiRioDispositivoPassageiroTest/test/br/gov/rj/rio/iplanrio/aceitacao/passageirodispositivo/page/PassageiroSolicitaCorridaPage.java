package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page;

import java.util.concurrent.TimeUnit;

import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;

import br.gov.rj.rio.iplanrio.aceitacao.infra.exception.AssertionFakeException;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class PassageiroSolicitaCorridaPage {
	AndroidDriver<?> driver;


	public PassageiroSolicitaCorridaPage(AndroidDriver<?> driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}


	public void solicitaCorrida(String taxistaNoPerimetro1500m) throws InterruptedException, AssertionFakeException {
		
		
	//	AppiumFieldDecorator decorator = new AppiumFieldDecorator(driver);
	//	decorator.DEFAULT_TIMEOUT = 5;

		 	Thread.sleep(2000); //verificar se podemos retirar
		 	 
 
			System.out.println("b1");
		 	

			System.out.println("Entrar : Solicitar Corrida");

 		driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));
 		driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);
 		driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();

 		System.out.println("b2");

		//**************************************************
		//clicar no botão avançar
 		esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_request_taxi"), 30);
 		System.out.println("b3");
		driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_request_taxi")).click();
		System.out.println("b4");
		System.out.println("taxistaNoPerimetro1500m:" + taxistaNoPerimetro1500m);
		if (!taxistaNoPerimetro1500m.equals("sim")) {
			 
		 	if (driver.findElements(By.xpath("//android.widget.TextView[@index='1']")).size()>0) {
		 		System.out.println("Infelizmente não encontramos Taxista para atender o seu pedido. Por favor tente novamente");
		 	 
					throw new AssertionFakeException("não há taxi disponível no perimetro de 1500 m ");
		 	}
	  
		 	System.out.println("b5");

		 driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		System.out.println("b6");
		
		while (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/tv_msg_wait")).size()  > 0) {
		//	System.out.println("aguardando terminar o aguarde...");
			System.out.println("b7");

		}
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("b8");
		
		
		 	}
		System.out.println("Sair : Solicitar Corrida");
/*
	 
		 Cenário não há taxista disponível

		if (cenarioTaxistaNoPerimetro.equals("não")) {

			if (driver.findElements(By.xpath("//android.widget.TextView[@text = 'Infelizmente não encontramos Taxista para atender o seu pedido. Por favor tente novamente']")).size()>0) {
				System.out.println("Não há taxistas");
				//clicar para Voltar tela

				driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));			  
				driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);			 
				driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();
			
				 
				//sai do caso de teste, pois o cenário não existe taxista nas mediações foi atendida
				 try {
					throw new AssertionFakeException("Ocorreu uma exceção esperada ");
				} catch (AssertionFakeException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 
				//driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/tv_close_dialog_discount")).click();
			}
		}  
 */
	}
	
	public void esperaPeloElementoNaoEmpty(final By by, int esperaEmsegundos) {

		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(100, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
		.withMessage("não encontrei >> " + by).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !d.findElements(by).isEmpty();
			//	return d.findElement(by).isDisplayed();
			}
		});

	}

	public void esperaPeloElemento(final By by, int esperaEmsegundos) {

		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(500, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
		.withMessage("não encontrei >> " + by).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				// System.out.println("***" + new
				// SimpleDateFormat("dd/mm/yyyy_hh:mm:ss.SSSXXX").frmat(new
				// Date()));

				return d.findElement(by).isDisplayed();
			}
		});

	}

	public void esperaPeloElementoEnabled(final By by) {
		new FluentWait<WebDriver>(driver).withTimeout(59, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return d.findElement(by).isEnabled();
			}
		});

	}

	

}

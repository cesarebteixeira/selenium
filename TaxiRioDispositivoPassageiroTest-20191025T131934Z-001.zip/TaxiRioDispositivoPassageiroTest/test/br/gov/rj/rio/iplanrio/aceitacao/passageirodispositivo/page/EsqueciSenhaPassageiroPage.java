package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;

import io.appium.java_client.android.AndroidDriver;

public class EsqueciSenhaPassageiroPage {
	
	private AndroidDriver<?>  driver;
	
public EsqueciSenhaPassageiroPage(AndroidDriver<?> driver) {
		
		
		this.driver = driver;
	}

public void VerificarConteudoDaMensagemPassageiro(String mensagem) {
	
	//driver.get("http://localhost:3000");
	//	esperaPeloElemento(By.name("login"));
			
		 
	
		esperaPeloElemento(By.xpath("//button[text()='Esqueci a senha']"), 10);
		
		driver.findElement(By.xpath("//button[text()='Esqueci a senha']")).click();
		
		esperaPeloElemento(By.xpath("//div[contains(text(),mensagem)]"), 10);
		
	
}
public void esperaPeloElemento(final By by, int tempoDeEspera) {

	new FluentWait<WebDriver>(driver).withTimeout(tempoDeEspera, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
			.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
			.withMessage("não encontrei >> " + by).until(new Function<WebDriver, Boolean>() {
				public Boolean apply(WebDriver d) {

					// System.out.println("***" + new
					// SimpleDateFormat("dd/mm/yyyy_hh:mm:ss.SSSXXX").frmat(new
					// Date()));

					return d.findElement(by).isDisplayed();
				}
			});

}

public void esperaPeloElementoEnabled(final By by, int tempoDeEspera) {
	new FluentWait<WebDriver>(driver).withTimeout(tempoDeEspera, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
			.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
				public Boolean apply(WebDriver d) {

					return d.findElement(by).isEnabled();
				}
			});

}

public void esperaPeloElementoDisabled(final By by, int tempoDeEspera) {
	new FluentWait<WebDriver>(driver).withTimeout(tempoDeEspera, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
			.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
				public Boolean apply(WebDriver d) {

					return !d.findElement(by).isEnabled();
				}
			});

}

public void esperaPeloElementoDesaparecer(final By by, int tempoDeEspera) {
	new FluentWait<WebDriver>(driver).withTimeout(tempoDeEspera, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
			.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
				public Boolean apply(WebDriver d) {

					return !(d.findElement(by).isDisplayed());
				}
			});

}



}

package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page;

import static org.testng.AssertJUnit.assertTrue;

import java.net.MalformedURLException;
import java.text.DecimalFormat;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;

public class PassageiroRecebeValorEAvaliaTaxistaPage {

	AndroidDriver<?> driver;

	String pageSourceFinalPassageiro;


	public PassageiroRecebeValorEAvaliaTaxistaPage(AndroidDriver<?> driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}


	public void recebeValorEAvaliaTaxista(String avaliaTaxista, String enviaComentario, String comentario, String avaliaTaxistaEstrelas,
			String informaOrigem, String informaDestino, String bandeiraEmUso,  String nomeTaxista, String marcaPlaca	) throws Exception {




		System.out.println("Entrar : recebeValorEAvaliaTaxista");
		
		Thread.sleep(1000);
	

		if (!avaliaTaxista.equals("nãoTesta")) {
			System.out.println("x1");
			driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));			  
			driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);			 
			driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();
			System.out.println("x2");
			if (avaliaTaxista.equals("sim")) {			

				if (avaliaTaxistaEstrelas.equals("4")) {
					avaliaTaxistaEstrelas= "0.8";
				}else 	if (avaliaTaxistaEstrelas.equals("3")) {
					avaliaTaxistaEstrelas = "0.6";
				}else 	if (avaliaTaxistaEstrelas.equals("2")) {
					avaliaTaxistaEstrelas = "0.4";
				}else 	if (avaliaTaxistaEstrelas.equals("1")) {
					avaliaTaxistaEstrelas = "0.2";
				}else 	if (avaliaTaxistaEstrelas.equals("5")) {
					avaliaTaxistaEstrelas = "1";
				}

				/*****  avalai o taxista */
				setRatingbar(avaliaTaxistaEstrelas);
				System.out.println("x3");

				//	driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/label_rating")).click();
				if (enviaComentario.equals("sim")){
					esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/edit_comment"),10);
					driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/edit_comment")).click();
					driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/edit_comment")).sendKeys(comentario);


					//verifica se o keyboard foi apresentado, se sim, retira ele
					hideKeyboard(driver);
				}


				//salvar os dados da página de menu final do passageiro com objetivo de fazer um assert
				//
		//		driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));		  
		// 		driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);		 
		// 	    driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();
				
			//	pageSourceFinalPassageiro = driver.getPageSource();
			//	System.out.println(pageSourceFinalPassageiro);
				
				//Não deve avaliar a origem e destino pois estas posições são pegas quando inicia a corrida (onde está o taxi) e local onde finaliza a corrida (onde está o taxci) e não os enderços passados
			//	FazAssertCorridaFizalidada(informaOrigem, informaDestino,bandeiraEmUso,nomeTaxista,marcaPlaca);
			 


				//enviar avaliação
				
		 
				

		 		esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_rating"), 30);

		 	driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_rating")).click();


			}else {
				esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_dismiss_rating"), 30);
				driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_dismiss_rating")).click();
			}



			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);

			while (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/tv_msg_wait")).size()  > 0) {
				//aguardando terminar o aguarde...

			}

			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		}else {
			
			System.out.println("Não será testado :recebeValorEAvaliaTaxista ");
			esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_dismiss_rating"), 30);
			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_dismiss_rating")).click();

		}


		System.out.println("Sair : recebeValorEAvaliaTaxista");
	//	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

	}


	private void FazAssertCorridaFizalidada(String informaOrigem, String informaDestino, String bandeiraEmUso, String nomeTaxista, String marcaPlaca) {



		//verifica se os endereços de origem e destino estão corretos
		// origem : 
		//	String  endOrigem =	driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/label_address_origin_rating")).getText();
		
		/*
		System.out.println("informaDestino :" + informaDestino);
		if (!informaOrigem.equals("nãoTesta")) {
			String message = "O valor '" + informaOrigem + "' não foi encontrado na página.";
			assertTrue(message, StringUtils.contains(pageSourceFinalPassageiro, informaOrigem));	
		}


		// destino
		// String endDestino = driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/label_address_destination_rating")).getText();
		System.out.println("informaDestino :" + informaDestino);
		if (!informaDestino.equals("nãoTesta")) {
			String message = "O valor '" + informaDestino + "' não foi encontrado na página.";
			assertTrue(message, StringUtils.contains(pageSourceFinalPassageiro, informaDestino));	
		}
		
		*/

		//verifica a bandeira em uso
		//String bandeiraEmUso = driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/label_flag")).getText()	;	
		System.out.println("bandeiraEmUso :" + bandeiraEmUso);
		String message = "O valor '" + bandeiraEmUso + "' não foi encontrado na página.";
		assertTrue(message, StringUtils.contains(pageSourceFinalPassageiro, bandeiraEmUso));
		
		
		 
		// verificar nome do taxista

		//String nomeTaxista = driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/label_driver_name")).getText();

		System.out.println("nomeTaxista :" + nomeTaxista);
		message = "O valor '" + nomeTaxista + "' não foi encontrado na página.";
		assertTrue(message, StringUtils.contains(pageSourceFinalPassageiro, nomeTaxista));

		// verificar modelo do carro e placa

		//String marcaCarroPlaca = driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/label_car")).getText();
		
		System.out.println("marcaPlaca :"+ marcaPlaca);

		message = "O valor '" + marcaPlaca + "' não foi encontrado na página.";
		assertTrue(message, StringUtils.contains(pageSourceFinalPassageiro, marcaPlaca));

		 

//verificar Labes Valor a pagar
/*
message = "O valor '" + dado.get(labelValorAPagar) + "' não foi encontrado na página.";
assertTrue(message, StringUtils.contains(resultadoFinalPasseiro, dado.get(labelValorAPagar)));	

		//verificar percentual de desconto aplicado
String percentualDesconto = driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/label_discount")).getText();
message = "O valor '" + percentualDesconto + "' não foi encontrado na página.";
assertTrue(message, StringUtils.contains(resultadoFinalPasseiro, percentualDesconto));	


	//verificar o valor do desconto
String valorDesconto = driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/discount")).getText();

  //verificar o valor com o desconto
 String valorDoDesconto = driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/discount_value")).getText();

		// verificar valor mínimo

	String valorAPagar =	driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/price_to_pay")).getText();
	message = "O valor '" + bandeiraEmUso + "' não foi encontrado na página.";
	assertTrue(message, StringUtils.contains(pageSourceFinalPassageiro, bandeiraEmUso));

	//verificar modo de pagamento

	String modoPagamento =driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/label_payment_method")).getText();

*/

	}


	public void setRatingbar(String rate) throws MalformedURLException,
	InterruptedException {

		WebElement fiveStarRatingbar = driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/label_rating"));

		float avaliacaoTaxista = Float.parseFloat(rate);
		//	String s = Float.toString(25.0f);


		// Get start point of fiveStarRatingbar.
		int startX = fiveStarRatingbar.getLocation().getX();
		//	System.out.println(startX); //255

		// Get end point of fiveStarRatingbar.
		int endX = fiveStarRatingbar.getSize().getWidth();
		//	System.out.println(endX); //630

		// Get vertical location of fiveStarRatingbar.
		int yAxis = fiveStarRatingbar.getLocation().getY();

		//	System.out.println(yAxis); //967

		// Set fiveStarRatingbar tap position to set Rating = 4 star.
		// You can use endX * 0.2 for 1 star, 	endX * 0.4 for 2 star, endX * 0.6
		// for 3 star, endX * 0.8 for 4 star, endX * 1 for 5 star.
		int tapAt = (int) (endX * avaliacaoTaxista) + (int) (endX  / 5);


		// Set fiveStarRatingbar to Rating = 1 star using TouchAction class.
		TouchAction act = new TouchAction(driver);
		act.press(tapAt, yAxis).release().perform();
		//	System.out.println("avaliação :" + avaliacaoTaxista); //126




	}


	public void esperaPeloElemento(final By by, int esperaEmsegundos) {

		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(250, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
		.withMessage("não encontrei >> " + by).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				// System.out.println("***" + new
				// SimpleDateFormat("dd/mm/yyyy_hh:mm:ss.SSSXXX").frmat(new
				// Date()));

				return d.findElement(by).isDisplayed();
			}
		});

	}

	public void esperaPeloElementoEnabled(final By by) {
		new FluentWait<WebDriver>(driver).withTimeout(59, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return d.findElement(by).isEnabled();
			}
		});

	}



	public void esperaPeloElementoDisabled(final By by,int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(50, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !d.findElement(by).isEnabled();
			}
		});

	}

	public void esperaPeloElementoDesaparecer(final By by, int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(250, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !(d.findElement(by).isDisplayed());
			}
		});

	}


	public static void hideKeyboard(AppiumDriver<?> driver) throws Exception {
		try {
			driver.hideKeyboard();
		} catch (Exception e) {
			//Lets ignore, apparently its throwing exception when keyboard was not opened
		}
	}




}

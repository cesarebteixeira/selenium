package br.gov.rj.rio.iplanrio.aceitacao.util;


public class ResultadoPlanilhaException extends Exception {

	
	private static final long serialVersionUID = -5479242579839457737L;

	public ResultadoPlanilhaException(String message) {

		super(message);
	}
}

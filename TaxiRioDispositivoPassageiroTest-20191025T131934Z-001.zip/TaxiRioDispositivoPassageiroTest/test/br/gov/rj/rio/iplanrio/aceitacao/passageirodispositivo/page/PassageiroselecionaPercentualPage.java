package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.Assert;

import com.google.common.base.Function;

import br.gov.rj.rio.iplanrio.aceitacao.infra.exception.AssertionFakeException;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class PassageiroselecionaPercentualPage {



	AndroidDriver<?> driver;


	public PassageiroselecionaPercentualPage(AndroidDriver<?> driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}


	public void passageiroSelecionaPercentual(String percetualDesconto, String taxistaDisponivel) throws AssertionFakeException, InterruptedException {

		Thread.sleep(2000);
		
	 
		System.out.println("Entrar : passageiroSelecionaPercentual");

		 	
		//taxista disponivel indica que taxista está dentro do raio de procura
		
		if (taxistaDisponivel.equals("sim")) {
			System.out.println("zava 1");
			driver.pressKeyCode(AndroidKeyCode.KEYCODE_BACK);
			System.out.println("zava 2");
		  	driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);
		  	System.out.println("zava 3");
	 	 	driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();
		 	System.out.println("zava 4");
			String indexPercentual = null;
			Thread.sleep(1000);
			esperaPeloElemento(By.xpath("//android.widget.TextView[@text='Desconto']"), 30);
			System.out.println("zava 5");
			if (percetualDesconto.equals("0")) {
				indexPercentual="0";
			}else if (percetualDesconto.equals("10")) {
				indexPercentual="1";
			}else if (percetualDesconto.equals("20")) {
				indexPercentual="2";
			}else if (percetualDesconto.equals("30")) {
				indexPercentual="3";
			}else if (percetualDesconto.equals("40")) {
				indexPercentual="4";
			}
			System.out.println("zava 6");
			esperaPeloElemento(By.xpath("//android.widget.LinearLayout[@index=" + indexPercentual + "]/android.widget.Button[@text='OK']	"), 30);
			System.out.println("zava 7");
			driver.pressKeyCode(AndroidKeyCode.KEYCODE_BACK);
			driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);
			driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();
			System.out.println("zava 8");
			// SELECIONA %  ***************************************
			driver.findElement(By.xpath("//android.widget.LinearLayout[@index=" + indexPercentual + "]/android.widget.Button[@text='OK']	")).click();
			System.out.println("zava 9");
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);  Não funciona
			
			 driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);   
			while (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/tv_msg_wait")).size()  > 0) {
				//aguardando terminar o aguarde...

			}
	//		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

			/*
	//tem situações onde a  tela cardapio de desconto fica em backend
	if (driver.findElements(By.id("com.android.systemui:id/dismiss_task")).size() > 0) {
		driver.findElement(By.id("com.android.systemui:id/dismiss_task")).click();
	}
			 */
		}else //não há taxista no raio de 1500 m
		{
			Assert.assertTrue(driver.findElements(By.xpath("//android.widget.TextView['Infelizmente não encontramos Taxista para atender o seu pedido. Por favor tente novamente']")).size()>0);
			//clicar no botão voltar
			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/tv_close_dialog_discount")).click();
			//sai para le um outro registro, teste executado com taxista a mais de 1500 m
		    throw new AssertionFakeException("Taxista a mais de 1500 m de distancia do passageiro ");
		}
		System.out.println("Sair : passageiroSelecionaPercentual");
	}

	public void esperaPeloElemento(final By by, int esperaEmsegundos) {

		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(100, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
		.withMessage("não encontrei >> " + by).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				// System.out.println("***" + new
				// SimpleDateFormat("dd/mm/yyyy_hh:mm:ss.SSSXXX").frmat(new
				// Date()));

				return d.findElement(by).isDisplayed();
			}
		});

	}

	public void esperaPeloElementoEnabled(final By by) {
		new FluentWait<WebDriver>(driver).withTimeout(59, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return d.findElement(by).isEnabled();
			}
		});

	}

	public void esperaPeloElementoDisabled(final By by,int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(50, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !d.findElement(by).isEnabled();
			}
		});

	}

	public void esperaPeloElementoDesaparecer(final By by, int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !(d.findElement(by).isDisplayed());
			}
		});

	}



	public static void hideKeyboard(AppiumDriver driver) throws Exception {
		try {
			driver.hideKeyboard();
		} catch (Exception e) {
			//Lets ignore, apparently its throwing exception when keyboard was not opened
		}
	}

}
package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class PassageiroInformaOrigemEDestinoPage {

	AndroidDriver<?> driver;


	public PassageiroInformaOrigemEDestinoPage(AndroidDriver<?> driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}


	public void informaEnderecoOrigem(String informaOrigem ) throws InterruptedException {

		
		
		
		Thread.sleep(1000);
		System.out.println("1");
//		System.out.println("Entrar : informaEnderecoOrigem " +  driver.currentActivity());
		if (!informaOrigem.equals("nãoTesta")) {
			System.out.println("2");

			driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));		  
			driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);		 
			driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();
			System.out.println("3");

			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/label_address_origin")).click();  
			esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/autocomplete_places"), 10);
			System.out.println("4");

			driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));		  
			driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);		 
			driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();
			System.out.println("5");

			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/autocomplete_places")).sendKeys(informaOrigem);
			System.out.println("6");
			esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/image"), 10);
			//br.gov.rj.taxi.rio.passenger:id/historyRecyclerView   não tem dados
			//		class :android.support.v7.widget.RecyclerView
			// verificar como fazer
			System.out.println("7");
			driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));		  
			driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);		 
			driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();

			System.out.println("8");

			//seleciona o primeiro  endereço disponibilizado

			driver.findElement(By.xpath("//android.widget.RelativeLayout[@resource-id='br.gov.rj.taxi.rio.passenger:id/predictedRow' and @index=0]")).click();
			System.out.println("9");

			//confirmo o endereço SE tiver mais de um
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			if (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/btn_address_selected")).size()>0) {
				System.out.println("10");
				driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_address_selected")).click();
				System.out.println("11");
			}else {
				System.out.println("Não tem mais de 1 endereço") ;
			}
			// espera retornar para tela AVANÇAR

			System.out.println("12");
		} else
			System.out.println("Não foi testatdo :   informaEnderecoOrigem");

		System.out.println("Sair :informaEnderecoOrigem");
		//espera o botão AVANÇAR aparecer
	//	refreshTelaAtual() ;
	//	esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_request_taxi"), 30);
								
	//	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 
	}


	public void informaEnderecoDestino(String informaDestino) throws InterruptedException {

	 
		
		Thread.sleep(1000);

		//teste

		System.out.println("a1");
		System.out.println("Entrar : informaEnderecoDestino " + driver.currentActivity());



		if (!informaDestino.equals("nãoTesta")) {
			System.out.println("a2");
			driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));			  
			driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);			 
			driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();
			System.out.println("a3");
			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/label_address_destination")).click(); 
			System.out.println("a4");
			esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/autocomplete_places"), 10);
			System.out.println("a5");

			driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));		  
			driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);		 
			driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();
			System.out.println("a6");
			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/autocomplete_places")).sendKeys(informaDestino);
			System.out.println("a7");
			esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/image"), 10);
			//br.gov.rj.taxi.rio.passenger:id/historyRecyclerView   não tem dados
			//		class :android.support.v7.widget.RecyclerView
			// verificar como fazer

			//	driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));		  
			//	driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);		 
			//	driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();		 


			//seleciona o primeiro  endereço disponibilizado

			System.out.println("a8");

			driver.findElement(By.xpath("//android.widget.RelativeLayout[@resource-id='br.gov.rj.taxi.rio.passenger:id/predictedRow' and @index=0]")).click();

			System.out.println("a9");

			//		driver.findElement(By.xpath("//android.widget.LinearLayout[@resource-id='br.gov.rj.taxi.rio.passenger:id/addressContent']")).click();

			//confirmo o endereço SE tiver mais de um
		//	driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

			 driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);   
			if (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/btn_address_selected")).size()>0) {
				System.out.println("a10");
			//	driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_address_selected")).click();
			}
			// espera retornar para tela AVANÇAR

		}else System.out.println("Não foi testado : informaEnderecoDestino");

		System.out.println("Sair : informaEnderecoDestino");
	//	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//espera botão AVANÇAR
	//	refreshTelaAtual() ;
	//	esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_request_taxi"), 30);
	}


	public void refreshTelaAtual() {
		
		driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));
		driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);
		driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();
		
	}



	public void esperaPeloElemento(final By by, int esperaEmsegundos) {

		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(500, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
		.withMessage("não encontrei >> " + by).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				// System.out.println("***" + new
				// SimpleDateFormat("dd/mm/yyyy_hh:mm:ss.SSSXXX").frmat(new
				// Date()));

				return d.findElement(by).isDisplayed();
			}
		});

	}

	public void esperaPeloElementoEnabled(final By by) {
		new FluentWait<WebDriver>(driver).withTimeout(59, TimeUnit.SECONDS).pollingEvery(500, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return d.findElement(by).isEnabled();
			}
		});

	}



	public void esperaPeloElementoDisabled(final By by,int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(500, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !d.findElement(by).isEnabled();
			}
		});

	}

	public void esperaPeloElementoDesaparecer(final By by, int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(500, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !(d.findElement(by).isDisplayed());
			}
		});

	}





}

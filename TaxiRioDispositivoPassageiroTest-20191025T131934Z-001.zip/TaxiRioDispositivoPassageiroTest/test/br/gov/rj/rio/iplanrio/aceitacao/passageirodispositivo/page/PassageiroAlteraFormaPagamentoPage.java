package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.Assert;

import com.google.common.base.Function;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;

public class PassageiroAlteraFormaPagamentoPage {



	AndroidDriver<?> driver;


	public  PassageiroAlteraFormaPagamentoPage(AndroidDriver<?> driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}


	public void selecionaFormaPagamento(String tipoPagamento) {

		System.out.println("Entrar : selecionaFormaPagamento");
		
		esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_change_payment_method"), 30);

		if (!tipoPagamento.equals("nãoTesta")) {

			//clicar no botão Alterar forma de pagamento
			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_change_payment_method")).click(); //clicou alterar
			driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));	  
			driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);
			driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();

			//TIPO PAGAMENTO = 2 É FORMA DE PAGAMENTO CARTÃO DE CRÉDITO
			if (tipoPagamento.equals("2")) {
				driver.findElement(By.xpath("//android.widget.TextView[@text='Cartão de crédito']")).click();
				driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				while (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/tv_msg_wait")).size()  > 0) {
					//aguardando terminar o aguarde...
				//system.out.println("aguarde....");
				}
				//TIPO PAGAMENTO = 3 É FORMA DE PAGAMENTO CARTÃO DE DEBITO
			}else if (tipoPagamento.equals("3")) {
				driver.findElement(By.xpath("//android.widget.TextView[@text='Cartão de débito']")).click();
				driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				while (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/tv_msg_wait")).size()  > 0) {
					//aguardando terminar o aguarde...
				//	System.out.println("aguarde....");
				}
				//TIPO PAGAMENTO = 1 É FORMA DE PAGAMENTO EM DINHEIRO
			}else if (tipoPagamento.equals("1")) {
				driver.findElement(By.xpath("//android.widget.TextView[@text='Cartão de débito']")).click();
				driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				while (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/tv_msg_wait")).size()  > 0) {
					//aguardando terminar o aguarde...
				//	System.out.println("aguarde....");
				}
			
			}else { // não testa forma de pagamento
				System.out.println("Não HÁ outra forma de pagamento");
			//	Assert.assertTrue(false);
			
			}



			//	driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			//clicar no botão voltar
			//	driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/tv_close_dialog_payment")).click();

		} 

		System.out.println("Sair : selecionaFormaPagamento");
		 

	}


	public void esperaPeloElemento(final By by, int esperaEmsegundos) {

		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(500, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
		.withMessage("não encontrei >> " + by).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				// System.out.println("***" + new
				// SimpleDateFormat("dd/mm/yyyy_hh:mm:ss.SSSXXX").frmat(new
				// Date()));

				return d.findElement(by).isDisplayed();
			}
		});

	}

	public void esperaPeloElementoEnabled(final By by) {
		new FluentWait<WebDriver>(driver).withTimeout(59, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return d.findElement(by).isEnabled();
			}
		});

	}



	public void esperaPeloElementoDisabled(final By by,int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(50, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !d.findElement(by).isEnabled();
			}
		});

	}

	public void esperaPeloElementoDesaparecer(final By by, int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(250, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !(d.findElement(by).isDisplayed());
			}
		});

	}

}
package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.test;

import java.util.Map;

import org.testng.annotations.BeforeClass;

import br.gov.rj.rio.iplanrio.aceitacao.infra.BaseAceitacaoTesteAndroid;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroHomePage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.CancelarPesquisaOrigemPage;

public class CancelarPesquisaOrigemTest extends BaseAceitacaoTesteAndroid{

	@Override
	protected void executaPassos(Map<String, String> dado) throws Exception {
		
		if (dado.get("fazLogin").equals("sim")) {
			 
			PassageiroHomePage aberturaPage = new PassageiroHomePage(driver);
			aberturaPage.LoginPage(dado.get("matricula"),  dado.get("senha"), dado.get("exit"), dado.get("resultadoEsperado"));
		}
		
		CancelarPesquisaOrigemPage cancelarPesquisaOrigemPage = new  CancelarPesquisaOrigemPage(driver);
	 
	}

	@Override
	@BeforeClass
	protected void beforeClass() {
		umTestador.carregaUmaPlanilha("CancelarPesquisaOrigem");
		umTestador.defineSeDeveReportarNoJira(false);
		umTestador.defineSeDeveReportarNoTestlink(false);
	}
	
}

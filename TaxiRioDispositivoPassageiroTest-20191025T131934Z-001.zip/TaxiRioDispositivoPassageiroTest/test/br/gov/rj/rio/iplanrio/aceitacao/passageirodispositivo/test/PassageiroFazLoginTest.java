package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.test;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;



import br.gov.rj.rio.iplanrio.aceitacao.infra.BaseAceitacaoTesteAndroid;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.AberturaPassageiroPage;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.PassageiroFazLoginPage;
import io.appium.java_client.android.AndroidDriver;
 

@Test
public class PassageiroFazLoginTest extends  BaseAceitacaoTesteAndroid{

	@Override
	protected void executaPassos(Map<String, String> dado) throws Exception {
		
 	 	if (dado.get("fazLogin").equals("sim")){
					
			PassageiroFazLoginPage passageiroFazloginPage = new PassageiroFazLoginPage((AndroidDriver<WebElement>) driver);
			passageiroFazloginPage.DigitaLogin(dado.get("login"));
			passageiroFazloginPage.DigitaSenha(dado.get("senha"));
					
				 		
	 	}
	} 
	@Override
	@BeforeClass
	protected void beforeClass() {
		umTestador.carregaUmaPlanilha("LoginPassageiro");
		umTestador.defineSeDeveReportarNoJira(false);
		umTestador.defineSeDeveReportarNoTestlink(false);
		
 
		
	}
	
}

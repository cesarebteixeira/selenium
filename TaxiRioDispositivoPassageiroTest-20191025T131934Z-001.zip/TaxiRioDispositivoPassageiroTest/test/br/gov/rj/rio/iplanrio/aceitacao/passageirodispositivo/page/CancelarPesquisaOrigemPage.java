package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page;

import io.appium.java_client.android.AndroidDriver;

public class CancelarPesquisaOrigemPage {

	private AndroidDriver<?>  driver;
	public CancelarPesquisaOrigemPage(AndroidDriver<?> driver) {
		 
		this.driver = driver;
	}

}

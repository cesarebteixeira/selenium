package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.FluentWait;

import com.google.common.base.Function;

import br.gov.rj.rio.iplanrio.aceitacao.infra.exception.AssertionFakeException;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class PassageiroEnviaMensagemTaxistaPage {
	AndroidDriver<?> driver;


	public PassageiroEnviaMensagemTaxistaPage(AndroidDriver<?> driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}



	public void enviaMensagemParaTaxista(String enviarMensagem, String numeroMensagem,  String taxistaResponde, String quemEnviaMensagemPrimeiro , 

			String passageiroResponde, String passageiroEnviaOutraMensagem , String taxistaEnviaOutraMensagem ) throws Exception {



		System.out.println("Entrar : enviaMensagemParaTaxista");

		esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_msg_driver_on_the_way"),30);

		//botão OK, entendi >br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it
		//botão Outra resposta >br.gov.rj.taxi.rio.passenger:id/btn_other_answer
		//otão Fechar > br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message

		if (!enviarMensagem.equals("nãoTesta")) {

			if (quemEnviaMensagemPrimeiro.equals("passageiro")) {
				System.out.println("Passageiro envará mensagem primeiro");
				//após taxista enviar uma mensagem, passageiro clica em outra resposta  e deixa o fluir seguir
				//Passageiro vai envira uma mensage e/ou responde uma mensagem do taxista

				esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_msg_driver_on_the_way"),30); // espera pelo botão MENSAGEM
				driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_msg_driver_on_the_way")).click(); //clicar botão mensagem
				System.out.println("vai trocar #1");
				trocarMensagemEntreTaxistaEPassageiro(  numeroMensagem,   passageiroResponde);  // PASSAGEIRO ENVIA MENSAGEM AO TAXISTA
				System.out.println("vai trocou  @1");

				while (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message")).size()==0) {


					if (taxistaResponde.equals("botaoOutraResposta")){ // 
						System.out.println("y16");
						if (passageiroEnviaOutraMensagem.equals("botaoOutraResposta")){
							esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_other_answer"), 60);
							driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_other_answer")).click(); //clicar botão mensagem
							System.out.println("vai trocar #2");
							trocarMensagemEntreTaxistaEPassageiro(  numeroMensagem,   passageiroResponde);  // PASSAGEIRO ENVIA MENSAGEM AO TAXISTA
							System.out.println("vai trocou  @2");
							esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message"),60);
							driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message")).click(); //botão FECHAR
							break;
						}


					}
				}

				if (taxistaResponde.equals("botaoOkEntendi")){ //passageiro recebe botão FECHAR
					System.out.println("y4");
					//passageiro fecha dialogo
					esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message"),60);
					driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message")).click(); //botão FECHAR
					System.out.println("y5");
				}

			}else 	if (quemEnviaMensagemPrimeiro.equals("taxista")) {

				if (passageiroResponde.equals("botaoOkEntendi")){ //taxista recee botão FECHAR
					System.out.println("y6");
					//taxista fecha dialogo
				//	refreshTelaAtual();
					
					//br.gov.rj.taxi.rio.passenger:id/btn_send_msg_driver_on_the_way (mensagem)
					esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it"),60);
					driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it")).click(); //botão OK< endenti > pass
					System.out.println("y7");
				}else if (passageiroResponde.equals("botaoOutraResposta")){ // 
					System.out.println("y8");
					if (taxistaEnviaOutraMensagem.equals("botaoOutraResposta")){			
												 
						esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_other_answer"), 60);
						driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_other_answer")).click(); //clicar botão outra resposta
						System.out.println("vai trocar >>  #3");
						trocarMensagemEntreTaxistaEPassageiro(  numeroMensagem,   passageiroResponde);  // PASSAGEIRO ENVIA MENSAGEM AO TAXISTA
						System.out.println("vai TROCOU >>  @3");
					//	esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message"),60);
					//	driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message")).click(); //botão FECHAR
						esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it"),60);
						driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it")).click(); //botão OK Entendi e taista vai fechar 
						
						System.out.println("y9");
					}


				}



			}
			/*	

				//		if (passageiroClicaMensagem.equals("sim")) {// passageiro envia mensagem ao taxista
				esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_msg_driver_on_the_way"),30); // espera pelo botão MENSAGEM
				driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_msg_driver_on_the_way")).click(); //clicar botão mensagem
				trocarMensagemEntreTaxistaEPassageiro(  numeroMensagem,   passageiroResponde);  // PASSAGEIRO ENVIA MENSAGEM AO TAXISTA

				//aqui colocaremos o código



				//	if (taxistaResponde.equals("botaoOutraResposta")) {	

				//	System.out.println("y3");
				//	esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_other_answer"), 10);
				////		driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_other_answer")).click(); //clicar no botão outra resposta
				//		trocarMensagemEntreTaxistaEPassageiro(  numeroMensagem,   passageiroResponde);
				if (taxistaResponde.equals("botaoOkEntendi")){ //passageiro recee botão FECHAR
					System.out.println("y4");
					//passageiro fecha dialogo
					esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message"),10);
					driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message")).click(); //botão FECHAR
					System.out.println("y5");
				}else if (taxistaResponde.equals("botaoOutraResposta")){ // 
					System.out.println("y6");
					if (passageiroEnviaOutraMensagem.equals("botaoOkEntendi")){		
						esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it"),10);
						driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it")).click(); //botão OK, entemdi


					}else if (passageiroEnviaOutraMensagem.equals("botaoOutraResposta")){
						driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_msg_driver_on_the_way")).click(); //clicar botão mensagem
						trocarMensagemEntreTaxistaEPassageiro(  numeroMensagem,   passageiroResponde);  // PASSAGEIRO ENVIA MENSAGEM AO TAXISTA
						esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message"),10);
						driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message")).click(); //botão FECHAR
					}
					//	}else if (taxistaResponde.equals("botaoOkEntendi")){
					//	if (taxistaResponde.equals("botaoOkEntendi")){
					//		esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message"),10);
					//		driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message")).click(); //botão FECHARSystem.out.println("passageiro já entendeu e termina o dialogo");


				}

			}else if (quemEnviaMensagemPrimeiro.equals("taxista")) {
				System.out.println("Taxista envará mensagem primeiro");
				//Passageiro espera pelos botões "OK, entendi" e "Outra Resposta". Escolhemos uma só.
				esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_other_answer"), 60); // espera pelo botão Outra resposta . Poderia ser o botão OK , entendi

				if (passageiroResponde.equals("botaoOkEntendi")){  
					System.out.println("y4");

					esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it"),10);
					driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it")).click(); //Botão Ok, entendi
					System.out.println("y5");
				}else if (passageiroResponde.equals("botaoOutraResposta")){ //passageiro recebe 
					System.out.println("y6");
					esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it"),10);
					driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it")).click(); //botão Outra Resposta	
					trocarMensagemEntreTaxistaEPassageiro(  numeroMensagem,   passageiroResponde);
				}
			}
			if (taxistaResponde.equals("botaoOkEntendi")){
				esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message"),10);
				driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message")).click(); //botão FECHARSystem.out.println("passageiro já entendeu e termina o dialogo");


			}
			 */

		}else System.out.println("Não faremos teste de mensageria");



		System.out.println("Sair : enviaMensagemParaTaxista");

	}

	public void enviaMensagemParaTaxistaTest(String enviarMensagem, String numeroMensagem,  String taxistaResponde, String quemEnviaMensagemPrimeiro , 

			String passageiroResponde  ) throws Exception {



		System.out.println("Entrar : enviaMensagemParaTaxista");


		//botão OK, entendi >br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it
		//botão Outra resposta >br.gov.rj.taxi.rio.passenger:id/btn_other_answer
		//otão Fechar > br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message

		if (!enviarMensagem.equals("nãoTesta")) {

			if (quemEnviaMensagemPrimeiro.equals("passageiro")) {
				System.out.println("Passageiro envará mensagem primeiro");
				//após taxista enviar uma mensagem, passageiro clica em outra resposta  e deixa o fluir seguir
				//Passageiro vai envira uma mensage e/ou responde uma mensagem do taxista
				//		if (passageiroClicaMensagem.equals("sim")) {// passageiro envia mensagem ao taxista
				esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_msg_driver_on_the_way"),30); // espera pelo botão MENSAGEM
				driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_msg_driver_on_the_way")).click(); //clicar botão mensagem
				trocarMensagemEntreTaxistaEPassageiro(  numeroMensagem,   passageiroResponde);  // PASSAGEIRO ENVIA MENSAGEM AO TAXISTA

				//aqui colocaremos o código



				if (taxistaResponde.equals("botaoOutraResposta")) {	

					System.out.println("y3");
					driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_other_answer")).click(); //clicar no botão outra resposta
					trocarMensagemEntreTaxistaEPassageiro(  numeroMensagem,   passageiroResponde);
					esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message"),60);
					driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message")).click(); //botão FECHAR
					System.out.println("y5");
				}else if (taxistaResponde.equals("botaoOkEntendi")){ //passageiro recee botão FECHAR
					System.out.println("y4");
					//passageiro fecha dialogo
					esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it"),60);
					driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it")).click(); //OK, entendi
					System.out.println("y5");

				}
			}else if (quemEnviaMensagemPrimeiro.equals("taxista")) {
				System.out.println("Taxista envará mensagem primeiro");
				//Passageiro espera pelos botões "OK, entendi" e "Outra Resposta". Escolhemos uma só.
				esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_other_answer"), 60); // espera pelo botão Outra resposta
				System.out.println("y2");
			}


		}else System.out.println("Não faremos teste de mensageria");
		System.out.println("Sair : enviaMensagemParaTaxista");

	}


	private void trocarMensagemEntreTaxistaEPassageiro(String numeroMensagem, String passageiroResponde) throws Exception {

	 
		System.out.println("entra : trocarMensagemEntreTaxistaEPassageiro");

		esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/edit_message"), 60);
		System.out.println("r1");
		driver.findElement(By.xpath("//android.widget.RadioButton[@index= " + numeroMensagem + "]")).click();  //selecionei a mensagem
		System.out.println("r2");

		if (!numeroMensagem.equals("5")) {
			System.out.println("r3");
			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_message")).click(); //Enviar
			System.out.println("r4");
		}else { //enviando mensagem escrita
			//	if (tipoDeResposta.equals("Outra resposta")) { // passsageiro vai enviar uma outra resposta r vai ficar aguarndado outra resposta
			System.out.println("r5");
			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/edit_message")).sendKeys("Sr. Motorista estou lhe aguardando a muito tempo, o que houve?");
			hideKeyboard(driver);
			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_message")).click();
			System.out.println("r6");

		}
		System.out.println("sai : trocarMensagemEntreTaxistaEPassageiro");
	}


	/*

	public void enviaMensagemParaTaxista(String enviarMensagem, String numeroMensagem,  String taxistaResponde, String quemEnviaMensagemPrimeiro , 

			String passageiroResponde  ) throws Exception {



		System.out.println("Entrar : enviaMensagemParaTaxista");




		if (!enviarMensagem.equals("nãoTesta")) {

			if (enviarMensagem.equals("sim")) { 	//Passageiro vai envira uma mensage e/ou responde uma mensagem do taxista
				//		if (passageiroClicaMensagem.equals("sim")) {// passageiro envia mensagem ao taxista
				esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_msg_driver_on_the_way"),30); // espera pelo botão MENSAGEM
				driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_msg_driver_on_the_way")).click(); //clicar botão mensagem
				trocarMensagemEntreTaxistaEPassageiro(  numeroMensagem,   passageiroResponde);  // PASSAGEIRO ENVIA MENSAGEM AO TAXISTA


				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}


				 driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);   
				//se uma dessas condições existir é pq o passageiro recebeu uma mensagem. Planilha decide o que fazer
				while (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it")).size()>0 ||  //botão > Ok, entendi
						driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/btn_other_answer")).size()>0 || //botão Outra resposta
						driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message")).size()>0) { //bbotão Fechar

					System.out.println("x1");
					//  taxista só pode responde (Ok, entendi ou outra resposta) respondeu OK entedi,   fecha a tela no passagero - Fim do dialogo
					//taxista responde Ok, entendi. Passageiro recebe somente o botão para fechar
					//	if (passageiroResponde.equals("fechar")) {
					//	if (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message")).size()>0) { //TAXISTA RESPONDEU ok, ENTENDI
					//			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message")).click(); //clicar no botão FECHAR}
					//		se taxista responder Outra resposta, 
					//	}else 
					if (taxistaResponde.equals("okEntendi")) {// || taxistaResponde.equals("okEntendi")){  // se passageiro receber ok entendi ou taxista resposndeu ok entendi
						System.out.println("x2");
						esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message"), 5);
						driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_close_dialog_message")).click(); // FECHA DIALOGO
						break;
					}else
						if (taxistaResponde.equals("outraResposta")) { //então vou enviar uma outra resposta também
							//	esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_msg_driver_on_the_way"),30); // espera pelo botão MENSAGEM
							//	driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_msg_driver_on_the_way")).click(); //clicar botão mensagem
							System.out.println("x3");
							esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_other_answer"), 30); // espera pelo botão Outra resposta
							driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_other_answer")).click(); //clicar no botão outra resposta
							trocarMensagemEntreTaxistaEPassageiro(  numeroMensagem,   passageiroResponde);

							//	int sair = 0;  //sair >> foi criado para sair do while, eu nao sei outra forma mas deve existir. depois melhoro
							 driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);   
							//termina dialogo clicansdo botão Ok, entendi
							while ((driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it")).size()>0  || driver.findElements(By.xpath("//android.widget.LinearLayout[@index=2]")).size()>0)  ) {
								//	driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));
								//	driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);
								//	driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();
								System.out.println("x4");
								 driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);   
								if (driver.findElements(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it")).size()>0) {
									//	esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it"), 10);
									System.out.println("x5");
									driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_ok_got_it")).click();
									break;
								}
								//termina o dialogo clicando no botão fechar
								 driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);   
								if (driver.findElements(By.xpath("//android.widget.LinearLayout[@index=2]")).size()>0) {
									//	esperaPeloElemento(By.xpath("//android.widget.LinearLayout[@index=2]"), 20);
									System.out.println("x6");
									driver.findElement(By.xpath("//android.widget.LinearLayout[@index=2]")).click();
									break;

								}

							}
						}



				}
			} System.out.println("Passageiro não vai enviar mensagem ao taxista");

		} 



		System.out.println("Sair : enviaMensagemParaTaxista");

	}

	private void trocarMensagemEntreTaxistaEPassageiro(String numeroMensagem, String passageiroResponde) throws Exception {

		System.out.println("passageiro enviando mensagem número "+ numeroMensagem);

		esperaPeloElemento(By.id("br.gov.rj.taxi.rio.passenger:id/edit_message"), 30);
		driver.findElement(By.xpath("//android.widget.RadioButton[@index= " + numeroMensagem + "]")).click();  //selecionei a mensagem

		if (!numeroMensagem.equals("5")) {

			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_message")).click(); //Enviar

		}else { //enviando mensagem escrita
			//	if (tipoDeResposta.equals("Outra resposta")) { // passsageiro vai enviar uma outra resposta r vai ficar aguarndado outra resposta
			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/edit_message")).sendKeys("Sr. Motorista estou lhe aguardando a muito tempo, o que houve?");
			hideKeyboard(driver);
			driver.findElement(By.id("br.gov.rj.taxi.rio.passenger:id/btn_send_message")).click();


		}
	}
	 */

	public void verificaSeTemSinalDeRede() {

		// sem não tiver sinal de rede, ficar tentando até que o sinal seja restabelecido, por 2 minutos

		if (driver.findElements(By.id("br.gov.rj.taxi.rio.driver:id/view_message")).size()>0) {

			driver.findElement(By.id("br.gov.rj.taxi.rio.driver:id/label_close_dialog_error_send_message")).click();  //clicar botão fechar



			System.out.println("não conseguimos estabelecer sinal com a rede");
			try {
				throw new AssertionFakeException("Estamos sem sinal de rede");
			} catch (AssertionFakeException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}


		}


	}

	public void refreshTelaAtual() {

		driver.pressKeyCode((AndroidKeyCode.KEYCODE_BACK));
		driver.pressKeyCode(AndroidKeyCode.KEYCODE_APP_SWITCH);
		driver.findElement(By.id("com.android.systemui:id/task_view_thumbnail")).click();

	}

	public void esperaPeloElemento(final By by, int esperaEmsegundos) {

		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(500, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
		.withMessage("não encontrei >> " + by).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				// System.out.println("***" + new
				// SimpleDateFormat("dd/mm/yyyy_hh:mm:ss.SSSXXX").frmat(new
				// Date()));

				return d.findElement(by).isDisplayed();
			}
		});

	}

	public void esperaPeloElementoEnabled(final By by) {
		new FluentWait<WebDriver>(driver).withTimeout(59, TimeUnit.SECONDS).pollingEvery(25, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return d.findElement(by).isEnabled();
			}
		});

	}



	public void esperaPeloElementoDisabled(final By by,int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(50, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !d.findElement(by).isEnabled();
			}
		});

	}

	public void esperaPeloElementoDesaparecer(final By by, int esperaEmsegundos) {
		new FluentWait<WebDriver>(driver).withTimeout(esperaEmsegundos, TimeUnit.SECONDS).pollingEvery(500, TimeUnit.MILLISECONDS)
		.ignoring(NoSuchElementException.class).until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver d) {

				return !(d.findElement(by).isDisplayed());
			}
		});

	}

	public static void hideKeyboard(AppiumDriver<?> driver) throws Exception {
		try {
			driver.hideKeyboard();
		} catch (Exception e) {
			//Lets ignore, apparently its throwing exception when keyboard was not opened
		}
	}


}

package br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.test;

import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import br.gov.rj.rio.iplanrio.aceitacao.infra.BaseAceitacaoTest;
import br.gov.rj.rio.iplanrio.aceitacao.infra.BaseAceitacaoTesteAndroid;
import br.gov.rj.rio.iplanrio.aceitacao.passageirodispositivo.page.EsqueciSenhaPassageiroPage;
 

@Test
public class EsqueciASenhaPassageiroTest extends BaseAceitacaoTesteAndroid {

	@Override
	protected void executaPassos(Map<String, String> dado) throws Exception {
		
		EsqueciSenhaPassageiroPage esqueciSenhaPassageiroPage = new EsqueciSenhaPassageiroPage(driver);
		esqueciSenhaPassageiroPage.VerificarConteudoDaMensagemPassageiro(dado.get("mensagem"));
		
	}

	@Override
	@BeforeClass
	protected void beforeClass() {
		umTestador.carregaUmaPlanilha("EsqueciASenhaPassageiro");
		umTestador.defineSeDeveReportarNoJira(false);
		umTestador.defineSeDeveReportarNoTestlink(false);
		
	}

}
